"""
3D structure generation for the in-browser viewer.

RDKit generates 3D coordinates (ETKDG embedding + MMFF minimization) and
returns them as a MOL block. The frontend hands the MOL block to 3Dmol.js.
No coordinates are invented — if embedding fails, we say so.
"""
from typing import Dict, Any

from rdkit import Chem
from rdkit.Chem import AllChem


def generate_3d_molblock(smiles: str) -> Dict[str, Any]:
    if not smiles or not isinstance(smiles, str):
        return {"valid": False, "error": "SMILES is required"}
    mol = Chem.MolFromSmiles(smiles.strip())
    if mol is None:
        return {"valid": False, "error": f"Invalid SMILES: '{smiles}'"}

    mol_h = Chem.AddHs(mol)
    params = AllChem.ETKDGv3()
    params.randomSeed = 0xC0FFEE
    embed_result = AllChem.EmbedMolecule(mol_h, params)
    if embed_result != 0:
        return {
            "valid": False,
            "error": "RDKit could not generate a 3D conformer for this molecule (embedding failed).",
        }

    try:
        AllChem.MMFFOptimizeMolecule(mol_h, maxIters=200)
        forcefield = "MMFF94"
    except Exception:
        try:
            AllChem.UFFOptimizeMolecule(mol_h, maxIters=200)
            forcefield = "UFF"
        except Exception:
            forcefield = "none (unminimized)"

    return {
        "valid": True,
        "smiles": Chem.MolToSmiles(mol),
        "molblock": Chem.MolToMolBlock(mol_h),
        "forcefield": forcefield,
        "num_atoms": mol_h.GetNumAtoms(),
        "num_bonds": mol_h.GetNumBonds(),
    }
