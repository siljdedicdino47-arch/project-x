import os
import sys
from dotenv import load_dotenv

# Load .env variables
load_dotenv()

from fastapi import FastAPI, HTTPException, Query, Response, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

from backend.admet_service import predict_admet
from backend.pubmed_service import search_pubmed_raw
from backend.chembrain import process_chat_message, synthesize_literature
from backend.chem_toolkit import (
    depict_svg,
    similarity_search,
    substructure_search,
    scaffold_analysis,
    generate_analogs,
)
from backend.advanced_modules import (
    docking_status,
    run_docking,
    quantum_chemistry,
    molecular_dynamics,
)
from backend.library_service import (
    init_db,
    list_compounds,
    add_compound,
    delete_compound,
    update_compound,
)
from backend.mol3d_service import generate_3d_molblock
from backend.mechanism_service import study_mechanism
from backend.protein_service import fetch_pdb
from backend.pharmacophore_service import extract_pharmacophore, shape_overlay
from backend.retro_service import retrosynthesize
from backend.tutor_service import tutor_answer
from backend.math_service import solve_math
from backend.practice_service import generate_practice, check_answer

init_db()

app = FastAPI(
    title="Scafflix ChemBrain API",
    description="Backend API for Scafflix drug discovery AI with ADMET prediction & PubMed literature tools",
    version="1.0.0"
)

# Enable CORS for frontend dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str = Field(..., example="Can you predict ADMET properties for Aspirin (CC(=O)OC1=CC=CC=C1C(=O)O)?")
    history: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    # Session-only override; never persisted server-side.
    api_key: Optional[str] = None


class MechanismRequest(BaseModel):
    question: str
    api_key: Optional[str] = None


class OverlayRequest(BaseModel):
    query_smiles: str
    reference_smiles: str


class TutorRequest(BaseModel):
    question: str
    subject: str = "general"
    grade: str = "uni-y1"
    history: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    api_key: Optional[str] = None


class MathRequest(BaseModel):
    expression: str
    operation: str  # solve | diff | integrate | factor | expand | simplify | limit | series
    variable: str = "x"
    lower: Optional[str] = None
    upper: Optional[str] = None
    order: int = 1


class PracticeRequest(BaseModel):
    subject: str
    grade: str
    topic: str
    count: int = 3
    api_key: Optional[str] = None


class AnswerCheckRequest(BaseModel):
    student: str
    canonical: str

class AdmetRequest(BaseModel):
    smiles: str = Field(..., example="CC(=O)OC1=CC=CC=C1C(=O)O")


class CompoundEntry(BaseModel):
    name: str = "Unnamed"
    smiles: str


class SimilarityRequest(BaseModel):
    smiles: str
    library: List[CompoundEntry] = Field(default_factory=list)
    top_k: int = 10


class SubstructureRequest(BaseModel):
    pattern: str
    library: List[CompoundEntry] = Field(default_factory=list)


class SmilesRequest(BaseModel):
    smiles: str


class DockingRequest(BaseModel):
    ligand_smiles: str
    receptor_pdbqt: Optional[str] = None
    center: Optional[Dict[str, float]] = None
    box_size: Optional[Dict[str, float]] = None


class LibraryAddRequest(BaseModel):
    name: str = "Unnamed"
    smiles: str
    tag: str = ""


class LibraryUpdateRequest(BaseModel):
    name: Optional[str] = None
    tag: Optional[str] = None


class BatchAdmetRequest(BaseModel):
    compounds: List[CompoundEntry] = Field(default_factory=list)

@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "service": "Scafflix ChemBrain API",
        "anthropic_configured": bool(os.getenv("ANTHROPIC_API_KEY"))
    }

@app.post("/admet")
def admet_endpoint(payload: AdmetRequest, response: Response):
    smiles = payload.smiles.strip() if payload.smiles else ""
    if not smiles:
        response.status_code = status.HTTP_400_BAD_REQUEST
        return {"valid": False, "error": "SMILES string is required"}
    
    result = predict_admet(smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
        return {"valid": False, "error": result.get("error", "Invalid SMILES")}
    
    return result

@app.get("/literature")
def literature_endpoint(response: Response, q: str = Query(..., description="Research question or search term")):
    query = q.strip() if q else ""
    if not query:
        response.status_code = status.HTTP_400_BAD_REQUEST
        return {"error": "Query string 'q' is required"}
    
    articles = search_pubmed_raw(query, max_results=10)
    if not articles:
        response.status_code = status.HTTP_404_NOT_FOUND
        return {"error": "No PubMed results found", "answer": "No PubMed articles were found matching your query.", "references": []}
    
    answer_text = synthesize_literature(query, articles)
    
    # Format references list per spec: title, authors, journal, year, pmid, url
    references = [
        {
            "title": art["title"],
            "authors": art["authors"],
            "journal": art["journal"],
            "year": art["year"],
            "pmid": art["pmid"],
            "url": art["url"]
        }
        for art in articles
    ]
    
    return {
        "answer": answer_text,
        "references": references
    }

@app.post("/chat")
def chat_endpoint(payload: ChatRequest):
    message = payload.message.strip() if payload.message else ""
    if not message:
        raise HTTPException(status_code=400, detail="Message string is required")

    chat_result = process_chat_message(
        message,
        payload.history or [],
        api_key_override=payload.api_key,
    )
    return chat_result


@app.post("/study/mechanism")
def mechanism_endpoint(payload: MechanismRequest, response: Response):
    result = study_mechanism(payload.question, api_key_override=payload.api_key)
    if not result.get("valid"):
        response.status_code = (
            status.HTTP_402_PAYMENT_REQUIRED if result.get("needs_key") else status.HTTP_400_BAD_REQUEST
        )
    return result


# ── Protein loader (RCSB) ────────────────────────────────────────────────

@app.get("/protein/{pdb_id}")
def protein_endpoint(pdb_id: str, response: Response):
    result = fetch_pdb(pdb_id)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


# ── Pharmacophore + shape overlay (RDKit) ────────────────────────────────

@app.post("/pharmacophore")
def pharmacophore_endpoint(payload: SmilesRequest, response: Response):
    result = extract_pharmacophore(payload.smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.post("/pharmacophore/overlay")
def overlay_endpoint(payload: OverlayRequest, response: Response):
    result = shape_overlay(payload.query_smiles, payload.reference_smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


# ── Retrosynthesis (template-based) ──────────────────────────────────────

@app.post("/retro")
def retro_endpoint(payload: SmilesRequest, response: Response):
    result = retrosynthesize(payload.smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


# ── Learn: tutor, math, practice ─────────────────────────────────────────

@app.post("/tutor")
def tutor_endpoint(payload: TutorRequest, response: Response):
    result = tutor_answer(
        payload.question,
        payload.subject,
        payload.grade,
        payload.history or [],
        api_key_override=payload.api_key,
    )
    if not result.get("valid"):
        response.status_code = (
            status.HTTP_402_PAYMENT_REQUIRED if result.get("needs_key") else status.HTTP_400_BAD_REQUEST
        )
    return result


@app.post("/math/solve")
def math_solve_endpoint(payload: MathRequest, response: Response):
    result = solve_math(
        payload.expression,
        payload.operation,
        variable=payload.variable,
        lower=payload.lower,
        upper=payload.upper,
        order=payload.order,
    )
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.post("/practice")
def practice_endpoint(payload: PracticeRequest, response: Response):
    result = generate_practice(
        payload.subject,
        payload.grade,
        payload.topic,
        count=payload.count,
        api_key_override=payload.api_key,
    )
    if not result.get("valid"):
        response.status_code = (
            status.HTTP_402_PAYMENT_REQUIRED if result.get("needs_key") else status.HTTP_400_BAD_REQUEST
        )
    return result


@app.post("/practice/check")
def practice_check_endpoint(payload: AnswerCheckRequest):
    return check_answer(payload.student, payload.canonical)


# ── Cheminformatics toolkit ──────────────────────────────────────────────

@app.post("/depict")
def depict_endpoint(payload: SmilesRequest, response: Response):
    result = depict_svg(payload.smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.post("/similarity")
def similarity_endpoint(payload: SimilarityRequest, response: Response):
    library = [{"name": c.name, "smiles": c.smiles} for c in payload.library]
    result = similarity_search(payload.smiles, library, top_k=payload.top_k)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.post("/substructure")
def substructure_endpoint(payload: SubstructureRequest, response: Response):
    library = [{"name": c.name, "smiles": c.smiles} for c in payload.library]
    result = substructure_search(payload.pattern, library)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.post("/scaffold")
def scaffold_endpoint(payload: SmilesRequest, response: Response):
    result = scaffold_analysis(payload.smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.post("/analogs")
def analogs_endpoint(payload: SmilesRequest, response: Response):
    result = generate_analogs(payload.smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


# ── Advanced modules (docking real; QM/MD are roadmap tiles) ─────────────

@app.get("/docking/status")
def docking_status_endpoint():
    return docking_status()


@app.post("/docking/run")
def docking_run_endpoint(payload: DockingRequest):
    return run_docking(
        payload.ligand_smiles,
        receptor_pdbqt=payload.receptor_pdbqt,
        center=payload.center,
        box_size=payload.box_size,
    )


@app.post("/quantum")
def quantum_endpoint(payload: SmilesRequest):
    return quantum_chemistry(payload.smiles)


@app.post("/dynamics")
def dynamics_endpoint(payload: SmilesRequest):
    return molecular_dynamics(payload.smiles)


# ── Compound library (SQLite) ─────────────────────────────────────────────

@app.get("/library")
def library_list_endpoint():
    return {"compounds": list_compounds()}


@app.post("/library")
def library_add_endpoint(payload: LibraryAddRequest, response: Response):
    result = add_compound(payload.name, payload.smiles, payload.tag)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


@app.patch("/library/{compound_id}")
def library_update_endpoint(compound_id: int, payload: LibraryUpdateRequest, response: Response):
    result = update_compound(compound_id, name=payload.name, tag=payload.tag)
    if not result.get("valid"):
        response.status_code = status.HTTP_404_NOT_FOUND
    return result


@app.delete("/library/{compound_id}")
def library_delete_endpoint(compound_id: int, response: Response):
    result = delete_compound(compound_id)
    if not result.get("valid"):
        response.status_code = status.HTTP_404_NOT_FOUND
    return result


# ── 3D structure ──────────────────────────────────────────────────────────

@app.post("/mol3d")
def mol3d_endpoint(payload: SmilesRequest, response: Response):
    result = generate_3d_molblock(payload.smiles)
    if not result.get("valid"):
        response.status_code = status.HTTP_400_BAD_REQUEST
    return result


# ── Batch ADMET (over an arbitrary compound list) ─────────────────────────

@app.post("/admet/batch")
def admet_batch_endpoint(payload: BatchAdmetRequest):
    rows = []
    for c in payload.compounds:
        smi = (c.smiles or "").strip()
        if not smi:
            rows.append({"name": c.name, "smiles": "", "valid": False, "error": "empty SMILES"})
            continue
        result = predict_admet(smi)
        if not result.get("valid"):
            rows.append({"name": c.name, "smiles": smi, "valid": False, "error": result.get("error", "invalid")})
            continue
        lip = result["lipinski"]
        props = result["properties"]
        rows.append({
            "name": c.name,
            "smiles": result["smiles"],
            "valid": True,
            "mw": lip["mw"],
            "logp": lip["logp"],
            "tpsa": lip["tpsa"],
            "hbd": lip["hbd"],
            "hba": lip["hba"],
            "lipinski_pass": lip["passes"],
            "lipinski_violations": lip["violations"],
            "logS": props["logS"]["value"],
            "hia": props["hia"]["value"],
            "bbb": props["bbb"]["value"],
            "herg": props["herg"]["value"],
            "logS_flag": props["logS"]["flag"],
            "logP_flag": props["logP"]["flag"],
            "hia_flag": props["hia"]["flag"],
            "bbb_flag": props["bbb"]["flag"],
            "herg_flag": props["herg"]["flag"],
        })
    return {"rows": rows, "count": len(rows)}
