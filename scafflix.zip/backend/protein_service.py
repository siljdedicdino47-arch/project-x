"""
Protein loader — fetches a real PDB from RCSB and returns its raw text plus a
small parsed manifest (title, chains, ligand HET codes). The frontend feeds the
raw PDB into 3Dmol.js for cartoon/surface visualization.

No structure prediction, no homology modeling — just real experimental structures
served straight from the PDB. If RCSB doesn't have the ID, we say so.
"""
import re
from typing import Dict, Any

import httpx

RCSB_URL = "https://files.rcsb.org/download/{pdb_id}.pdb"


def fetch_pdb(pdb_id: str) -> Dict[str, Any]:
    pid = (pdb_id or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{4}", pid):
        return {"valid": False, "error": f"PDB IDs are 4 alphanumeric characters (e.g. 1ATP). Got: {pdb_id!r}"}

    try:
        r = httpx.get(RCSB_URL.format(pdb_id=pid), timeout=20.0, follow_redirects=True)
    except Exception as e:
        return {"valid": False, "error": f"Could not reach RCSB: {e}"}

    if r.status_code == 404:
        return {"valid": False, "error": f"No PDB entry with ID {pid} on RCSB."}
    if r.status_code != 200:
        return {"valid": False, "error": f"RCSB returned HTTP {r.status_code}"}

    pdb_text = r.text
    title = _parse_title(pdb_text)
    chains = _parse_chains(pdb_text)
    ligands = _parse_ligands(pdb_text)
    resolution = _parse_resolution(pdb_text)

    return {
        "valid": True,
        "pdb_id": pid,
        "title": title,
        "chains": sorted(chains),
        "ligands": sorted(ligands - {"HOH"}),
        "resolution_A": resolution,
        "num_atoms": sum(1 for line in pdb_text.splitlines() if line.startswith(("ATOM", "HETATM"))),
        "pdb": pdb_text,
    }


def _parse_title(text: str) -> str:
    lines = [ln[10:].strip() for ln in text.splitlines() if ln.startswith("TITLE")]
    return " ".join(lines).strip() or "(no title)"


def _parse_chains(text: str) -> set[str]:
    chains: set[str] = set()
    for ln in text.splitlines():
        if ln.startswith("ATOM") and len(ln) > 22:
            chains.add(ln[21])
    return chains


def _parse_ligands(text: str) -> set[str]:
    ligs: set[str] = set()
    for ln in text.splitlines():
        if ln.startswith("HETATM") and len(ln) > 20:
            resname = ln[17:20].strip()
            if resname:
                ligs.add(resname)
    return ligs


def _parse_resolution(text: str) -> float | None:
    for ln in text.splitlines():
        if ln.startswith("REMARK   2 RESOLUTION."):
            m = re.search(r"([\d.]+)\s*ANGSTROM", ln)
            if m:
                try:
                    return float(m.group(1))
                except ValueError:
                    pass
    return None
