"""
Practice-problem generator (LLM-backed) and answer checker.

Given a subject + grade + topic, the LLM produces a small JSON pack of
problems, each with a canonical answer and a step-by-step solution. The checker
compares a student's answer against the canonical one (loose match — case and
whitespace insensitive) and reveals the solution.

The LLM is called via a forced tool schema so the response is always structured.
"""
from typing import Dict, Any, List, Optional

from backend.chembrain import get_client


PRACTICE_TOOL = {
    "name": "submit_practice_pack",
    "description": (
        "Return a set of practice problems as a structured object. Do not write "
        "freeform prose outside the tool call."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "topic": {"type": "string"},
            "problems": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "index": {"type": "integer"},
                        "question": {"type": "string"},
                        "answer": {"type": "string", "description": "Concise canonical answer for auto-grading (short — a number, a formula, a term, or a single sentence)."},
                        "solution": {"type": "string", "description": "Step-by-step worked solution. Use LaTeX in $$...$$ where useful."},
                        "hint": {"type": "string", "description": "One-sentence nudge for a stuck student."},
                    },
                    "required": ["index", "question", "answer", "solution"],
                },
            },
        },
        "required": ["topic", "problems"],
    },
}


def _system_prompt(subject: str, grade: str, topic: str, count: int) -> str:
    return f"""You generate practice problems for a personal tutor app.

Subject: {subject}. Student grade level: {grade}. Requested topic: {topic}.
Produce exactly {count} problems, ordered easiest → hardest.

RULES:
1. Use the `submit_practice_pack` tool. Do not write prose outside the tool.
2. Each `answer` must be short and unambiguous — auto-graded by string compare after trimming.
   - For math, prefer decimals rounded to 2dp, OR the simplest exact form (e.g. "1/2", "\\sqrt{{2}}").
   - For chem, prefer the canonical SMILES, IUPAC name, or single-word answer.
   - For English/history, prefer a single term or short phrase.
3. `solution` shows the full reasoning as if teaching. Use LaTeX where math clarifies.
4. Do not fabricate references, paper citations, or invented statistics.
5. Match difficulty to the stated grade level — do not go harder or easier."""


def generate_practice(
    subject: str,
    grade: str,
    topic: str,
    count: int = 3,
    api_key_override: Optional[str] = None,
) -> Dict[str, Any]:
    if not (subject and grade and topic):
        return {"valid": False, "error": "Subject, grade, and topic are all required."}

    client = get_client(api_key_override)
    if client is None:
        return {
            "valid": False,
            "needs_key": True,
            "error": (
                "Practice generation needs an Anthropic key. Paste one in the "
                "header (session-only) or use the Math workbench (SymPy) directly."
            ),
        }

    n = max(1, min(int(count or 3), 8))
    try:
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=3000,
            system=_system_prompt(subject, grade, topic, n),
            tools=[PRACTICE_TOOL],
            tool_choice={"type": "tool", "name": "submit_practice_pack"},
            messages=[{"role": "user", "content": f"Generate {n} {subject} problems on {topic!r} for a {grade} student."}],
        )
    except Exception as e:
        return {"valid": False, "error": f"LLM error: {e}"}

    payload: Optional[Dict[str, Any]] = None
    for block in response.content:
        if getattr(block, "type", None) == "tool_use" and block.name == "submit_practice_pack":
            payload = block.input
            break

    if not payload:
        return {"valid": False, "error": "LLM did not return a structured practice pack."}

    problems: List[Dict[str, Any]] = []
    for p in payload.get("problems", []):
        problems.append({
            "index":    int(p.get("index", len(problems) + 1)),
            "question": (p.get("question") or "").strip(),
            "answer":   (p.get("answer") or "").strip(),
            "solution": (p.get("solution") or "").strip(),
            "hint":     (p.get("hint") or "").strip(),
        })

    return {
        "valid": True,
        "subject": subject,
        "grade": grade,
        "topic": payload.get("topic") or topic,
        "problems": problems,
    }


def check_answer(student: str, canonical: str) -> Dict[str, Any]:
    a = (student or "").strip().lower()
    b = (canonical or "").strip().lower()
    if not b:
        return {"correct": False, "note": "No canonical answer to check against."}
    if a == b:
        return {"correct": True, "note": "Match."}
    # Tolerant numeric compare: if both parse as floats, check within 1%.
    try:
        af = float(a.replace(",", ""))
        bf = float(b.replace(",", ""))
        if bf == 0:
            return {"correct": abs(af) < 1e-6, "note": "Compared as numbers."}
        rel = abs(af - bf) / abs(bf)
        return {"correct": rel < 0.01, "note": f"Compared as numbers · relative error {rel:.2%}"}
    except Exception:
        pass
    # Trim punctuation for text answers.
    a2 = "".join(ch for ch in a if ch.isalnum() or ch.isspace()).strip()
    b2 = "".join(ch for ch in b if ch.isalnum() or ch.isspace()).strip()
    return {"correct": a2 == b2, "note": "Compared as text (punctuation-insensitive)."}
