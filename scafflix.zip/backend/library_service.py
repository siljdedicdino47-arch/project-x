"""
Persistent compound library backed by SQLite.

One table, no auth. Every compound is validated with RDKit before it lands in
the database, so downstream tools never see a garbage SMILES from this store.
"""
import os
import sqlite3
from contextlib import contextmanager
from typing import List, Dict, Any, Optional

from rdkit import Chem


DB_PATH = os.getenv("SCAFFLIX_DB", os.path.join(os.path.dirname(__file__), "scafflix.db"))


_SEED = [
    ("Aspirin",     "CC(=O)OC1=CC=CC=C1C(=O)O",                           "Analgesic"),
    ("Caffeine",    "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",                       "CNS stimulant"),
    ("Ibuprofen",   "CC(C)CC1=CC=C(C=C1)C(C)C(=O)O",                      "NSAID"),
    ("Paracetamol", "CC(=O)NC1=CC=C(C=C1)O",                              "Analgesic"),
    ("Imatinib",    "CC1=C(C=C(C=C1)NC(=O)C2=CC=C(C=C2)CN3CCN(CC3)C)NC4=NC=CC(=N4)C5=CN=CC=C5",
                                                                          "Kinase inhibitor"),
    ("Naproxen",    "COC1=CC2=CC=C(C=C2C=C1)C(C)C(=O)O",                  "NSAID"),
]


@contextmanager
def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS compounds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                smiles TEXT NOT NULL,
                canonical_smiles TEXT NOT NULL,
                tag TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_compounds_canonical ON compounds (canonical_smiles)")
        count = c.execute("SELECT COUNT(*) FROM compounds").fetchone()[0]
        if count == 0:
            for name, smi, tag in _SEED:
                mol = Chem.MolFromSmiles(smi)
                if mol is None:
                    continue
                c.execute(
                    "INSERT INTO compounds (name, smiles, canonical_smiles, tag) VALUES (?, ?, ?, ?)",
                    (name, smi, Chem.MolToSmiles(mol), tag),
                )


def list_compounds() -> List[Dict[str, Any]]:
    with _conn() as c:
        rows = c.execute(
            "SELECT id, name, smiles, canonical_smiles, tag, created_at "
            "FROM compounds ORDER BY id"
        ).fetchall()
        return [dict(r) for r in rows]


def add_compound(name: str, smiles: str, tag: str = "") -> Dict[str, Any]:
    name = (name or "").strip() or "Unnamed"
    smiles = (smiles or "").strip()
    if not smiles:
        return {"valid": False, "error": "SMILES is required"}
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"valid": False, "error": f"Invalid SMILES: {smiles}"}
    canonical = Chem.MolToSmiles(mol)
    with _conn() as c:
        existing = c.execute(
            "SELECT id FROM compounds WHERE canonical_smiles = ?", (canonical,)
        ).fetchone()
        if existing:
            return {"valid": False, "error": f"Compound already in library (id={existing['id']})"}
        cur = c.execute(
            "INSERT INTO compounds (name, smiles, canonical_smiles, tag) VALUES (?, ?, ?, ?)",
            (name, smiles, canonical, (tag or "").strip()),
        )
        row = c.execute(
            "SELECT id, name, smiles, canonical_smiles, tag, created_at FROM compounds WHERE id = ?",
            (cur.lastrowid,),
        ).fetchone()
    return {"valid": True, "compound": dict(row)}


def delete_compound(compound_id: int) -> Dict[str, Any]:
    with _conn() as c:
        row = c.execute("SELECT id FROM compounds WHERE id = ?", (compound_id,)).fetchone()
        if not row:
            return {"valid": False, "error": f"No compound with id {compound_id}"}
        c.execute("DELETE FROM compounds WHERE id = ?", (compound_id,))
    return {"valid": True, "deleted": compound_id}


def update_compound(compound_id: int, name: Optional[str] = None, tag: Optional[str] = None) -> Dict[str, Any]:
    with _conn() as c:
        row = c.execute("SELECT id FROM compounds WHERE id = ?", (compound_id,)).fetchone()
        if not row:
            return {"valid": False, "error": f"No compound with id {compound_id}"}
        if name is not None:
            c.execute("UPDATE compounds SET name = ? WHERE id = ?", (name.strip() or "Unnamed", compound_id))
        if tag is not None:
            c.execute("UPDATE compounds SET tag = ? WHERE id = ?", (tag.strip(), compound_id))
        row = c.execute(
            "SELECT id, name, smiles, canonical_smiles, tag, created_at FROM compounds WHERE id = ?",
            (compound_id,),
        ).fetchone()
    return {"valid": True, "compound": dict(row)}
