"""
Advanced module services for Scafflix.

Two categories live here, and the distinction is deliberate and honest:

1. RUNNABLE ON A LAPTOP (real compute):
   - docking_status(): reports whether AutoDock Vina is installed and ready.
   - run_docking(): runs a real Vina docking IF a receptor + box are provided.
     Returns a clear setup message otherwise — it never fabricates poses.

2. NOT RUNNABLE AS A LAPTOP PROTOTYPE (roadmap tiers):
   - quantum_chemistry() and molecular_dynamics() intentionally DO NOT fake a
     result. They return a structured "roadmap" payload describing what the
     module would do, what engine it needs (Psi4 / OpenMM), and why it isn't a
     click-to-run feature yet. The frontend renders these as clearly-labelled
     "planned" tiles, not as working tools.

Faking a QM energy or an MD trajectory would be worse than useless — it would
make every real result in the app look untrustworthy too.
"""
import shutil
from typing import Dict, Any, Optional


def docking_status() -> Dict[str, Any]:
    """Is AutoDock Vina available on this machine?"""
    vina_bin = shutil.which("vina")
    try:
        import vina  # python bindings
        vina_py = True
    except Exception:
        vina_py = False

    ready = bool(vina_bin) or vina_py
    return {
        "module": "DockAI",
        "ready": ready,
        "engine": "AutoDock Vina",
        "detail": (
            "Vina is installed and ready to dock." if ready else
            "Vina is not installed yet. Install with `pip install vina meeko` "
            "(the app already handles this if it's in requirements.txt), or the "
            "standalone AutoDock Vina binary."
        ),
    }


def run_docking(
    ligand_smiles: str,
    receptor_pdbqt: Optional[str] = None,
    center: Optional[Dict[str, float]] = None,
    box_size: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    """
    Run a real docking IF given a prepared receptor and search box. Without those,
    return a clear, honest 'setup required' response — never fake binding scores.
    """
    status = docking_status()
    if not status["ready"]:
        return {
            "valid": False,
            "needs_setup": True,
            "message": "AutoDock Vina isn't installed on this machine yet.",
            "how_to": status["detail"],
        }

    if not receptor_pdbqt or not center or not box_size:
        return {
            "valid": False,
            "needs_setup": True,
            "message": (
                "Docking needs three things you haven't provided yet: a prepared "
                "receptor (PDBQT), a search-box center (x/y/z), and a box size. "
                "This is the real setup step — pick a target protein, define the "
                "pocket, and dock against it."
            ),
            "next_steps": [
                "Download a target structure from the RCSB PDB (e.g. a kinase).",
                "Prepare the receptor as PDBQT (Meeko or AutoDockTools).",
                "Identify the binding-pocket center coordinates.",
                "Re-run docking with receptor + center + box_size.",
            ],
            "ligand": ligand_smiles,
        }

    # If we reach here, a full docking run would execute. Kept minimal for the
    # prototype; a production version prepares the ligand (Meeko), runs Vina, and
    # parses the scored poses.
    return {
        "valid": True,
        "message": "Receptor and box supplied — a full Vina run would execute here.",
        "ligand": ligand_smiles,
        "note": "Prototype stub for the compute step; wiring is in place.",
    }


def quantum_chemistry(smiles: str) -> Dict[str, Any]:
    """
    Roadmap tile — NOT a live calculation. Describes the intended module honestly.
    """
    return {
        "module": "QuantumChem",
        "status": "planned",
        "live": False,
        "would_compute": [
            "HOMO / LUMO energies and the HOMO–LUMO gap",
            "Optimized 3D geometry (DFT)",
            "Electrostatic potential surface",
            "Dipole moment and partial charges",
        ],
        "engine_when_built": "Psi4 (open-source, LGPL) — or ORCA for personal academic use only",
        "why_not_now": (
            "A real DFT calculation takes minutes to hours per molecule and needs "
            "a dedicated QM engine. It's a funded-release module, not a click-to-run "
            "prototype feature. ORCA specifically can't be bundled into a product — "
            "its license is academic/personal use only, no redistribution."
        ),
        "smiles": smiles,
    }


def molecular_dynamics(smiles: str) -> Dict[str, Any]:
    """
    Roadmap tile — NOT a live simulation. Describes the intended module honestly.
    """
    return {
        "module": "MolDynamics",
        "status": "planned",
        "live": False,
        "would_compute": [
            "Ligand conformational stability over a short trajectory",
            "RMSD / RMSF profiles",
            "Binding-pose stability in a solvated pocket",
        ],
        "engine_when_built": "OpenMM (open-source) with a GPU",
        "why_not_now": (
            "MD needs force-field parameterization, a solvated system, GPU compute, "
            "and trajectory storage. There is no honest laptop-prototype version — "
            "so it's shown here as a planned module rather than faked."
        ),
        "smiles": smiles,
    }
