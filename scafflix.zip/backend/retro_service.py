"""
Template-based one-step retrosynthesis.

Applies a curated list of REVERSE reactions (reaction SMARTS) to the target
molecule. Each hit is a real disconnection — the resulting fragments, when run
through the forward reaction, reconstruct the target.

This is a *teaching-grade* retrosynthesis tool. It is NOT AiZynthFinder or a
neural template model. It doesn't rank routes by feasibility, doesn't check
functional group compatibility, and doesn't recurse beyond one step. Use it to
brainstorm disconnections, not to plan a synthesis.
"""
from typing import Dict, Any, List

from rdkit import Chem
from rdkit.Chem import AllChem


# name, retro-SMARTS (product >> reactants), forward name for readability
_TEMPLATES = [
    ("Amide bond",         "[C:1](=[O:2])[NH1:3][*:4]>>[C:1](=[O:2])[OH].[NH2:3][*:4]",
     "Amide → carboxylic acid + amine"),
    ("Ester bond",         "[C:1](=[O:2])[O:3][C:4]>>[C:1](=[O:2])[OH].[OH:3][C:4]",
     "Ester → carboxylic acid + alcohol"),
    ("Reductive amination","[C:1][NH1:2][C:3]>>[C:1]=[O].[NH2:2][C:3]",
     "sec. amine → carbonyl + primary amine"),
    ("Wittig alkene",      "[C:1]=[C:2]>>[C:1]=O.[P](c1ccccc1)(c1ccccc1)(c1ccccc1)=[C:2]",
     "C=C → aldehyde/ketone + phosphorus ylide"),
    ("Suzuki coupling",    "[c:1]-[c:2]>>[c:1][Br].[c:2]B(O)O",
     "biaryl → aryl bromide + arylboronic acid"),
    ("SNAr",               "[c:1][NH1:2][*:3]>>[c:1][F].[NH2:2][*:3]",
     "aryl amine → aryl fluoride + amine (SNAr)"),
    ("Grignard addition",  "[C:1]([OH:2])([C:3])[C:4]>>[C:1](=[O:2])[C:3].[Br][C:4]",
     "sec./tert. alcohol → carbonyl + alkyl halide"),
    ("Aldol",              "[C:1]([OH:2])[CH1:3][C:4](=[O:5])>>[C:1](=[O:2]).[CH2:3][C:4](=[O:5])",
     "β-hydroxy carbonyl → two carbonyls"),
    ("Diels–Alder",        "[C:1]1[C:2][C:3]=[C:4][C:5][C:6]1>>[C:1]=[C:2].[C:3]=[C:4]/[C:5]=[C:6]",
     "cyclohexene → diene + dienophile"),
    ("Ether Williamson",   "[C:1][O:2][C:3]>>[C:1][Br].[OH:2][C:3]",
     "ether → alkyl halide + alcohol"),
]


def _apply_retro(target: Chem.Mol, smarts: str) -> List[List[str]]:
    """Return unique fragment sets produced by a retro-SMARTS. Silent on failure."""
    try:
        rxn = AllChem.ReactionFromSmarts(smarts)
    except Exception:
        return []
    if rxn is None:
        return []
    try:
        products = rxn.RunReactants((target,))
    except Exception:
        return []

    seen: set = set()
    unique_sets: List[List[str]] = []
    for prod_tuple in products:
        pieces: List[str] = []
        ok = True
        for mol in prod_tuple:
            try:
                Chem.SanitizeMol(mol)
                pieces.append(Chem.MolToSmiles(mol))
            except Exception:
                ok = False
                break
        if not ok or not pieces:
            continue
        key = tuple(sorted(pieces))
        if key in seen:
            continue
        seen.add(key)
        unique_sets.append(pieces)
    return unique_sets


def retrosynthesize(smiles: str) -> Dict[str, Any]:
    if not smiles:
        return {"valid": False, "error": "Please provide a target SMILES."}
    target = Chem.MolFromSmiles(smiles.strip())
    if target is None:
        return {"valid": False, "error": f"Invalid SMILES: {smiles!r}"}
    canonical = Chem.MolToSmiles(target)

    disconnections: List[Dict[str, Any]] = []
    for name, retro_smarts, description in _TEMPLATES:
        fragments_list = _apply_retro(target, retro_smarts)
        for frags in fragments_list:
            disconnections.append({
                "name": name,
                "description": description,
                "fragments": frags,
            })

    return {
        "valid": True,
        "target": canonical,
        "disconnections": disconnections,
        "count": len(disconnections),
        "note": (
            "Teaching-grade template retrosynthesis. Ten curated disconnections; "
            "single-step only; no route ranking or feasibility filter. For a real "
            "planner, use AiZynthFinder or Chemputer."
        ),
    }
