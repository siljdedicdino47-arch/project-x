"""
Real math workbench powered by SymPy.

No LLM required. Every result is a genuine SymPy computation:
- solve(expr, symbol)         — algebraic equations
- diff(expr, symbol, n)       — differentiation
- integrate(expr, symbol)     — indefinite integrals
- integrate(expr, (s, a, b))  — definite integrals
- factor(expr) / expand(expr) / simplify(expr) / together(expr)
- limit(expr, s, point)
- series(expr, s, point, n)

The frontend renders `latex` fields with KaTeX.
"""
from typing import Dict, Any, Optional

import sympy as sp
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application, convert_xor


_TRANSFORMS = standard_transformations + (
    implicit_multiplication_application,  # so "2x" parses as 2*x
    convert_xor,                          # so "x^2" parses as x**2
)


def _parse(expression: str) -> Optional[sp.Expr]:
    """Parse a user-friendly math expression string into a SymPy expr."""
    try:
        # SymPy locals so common single-letter variables and functions work.
        locals_map = {"e": sp.E, "pi": sp.pi, "i": sp.I, "oo": sp.oo, "infty": sp.oo}
        return parse_expr(expression, transformations=_TRANSFORMS, local_dict=locals_map)
    except Exception:
        return None


def _sym(name: str) -> sp.Symbol:
    return sp.Symbol(name)


def _latex(x: Any) -> str:
    try:
        return sp.latex(x)
    except Exception:
        return str(x)


def _fmt_result(input_expr: str, operation: str, output: Any, steps: list[str]) -> Dict[str, Any]:
    return {
        "valid": True,
        "operation": operation,
        "input": input_expr,
        "input_latex": _latex(_parse(input_expr)) if input_expr else "",
        "output": str(output),
        "output_latex": _latex(output),
        "steps": steps,
    }


def solve_math(
    expression: str,
    operation: str,
    variable: str = "x",
    lower: Optional[str] = None,
    upper: Optional[str] = None,
    order: int = 1,
) -> Dict[str, Any]:
    """Route a math request to SymPy. Every path is real computation."""
    expr = _parse(expression)
    if expr is None:
        return {"valid": False, "error": f"Could not parse expression: {expression!r}"}
    var = _sym(variable or "x")

    try:
        if operation == "solve":
            # Accept "expr = rhs" or plain "expr" (assumes = 0).
            if "=" in expression:
                lhs_s, rhs_s = expression.split("=", 1)
                lhs = _parse(lhs_s)
                rhs = _parse(rhs_s)
                if lhs is None or rhs is None:
                    return {"valid": False, "error": "Could not parse both sides of the equation."}
                eq = sp.Eq(lhs, rhs)
                sols = sp.solve(eq, var)
            else:
                eq = sp.Eq(expr, 0)
                sols = sp.solve(eq, var)
            steps = [
                f"Read the equation: ${_latex(eq)}$",
                f"Solve for ${variable}$ (SymPy `solve`).",
                f"Solutions: {', '.join('$' + _latex(s) + '$' for s in sols) if sols else 'no solutions'}",
            ]
            return _fmt_result(expression, "solve", sols, steps)

        if operation == "diff":
            n = max(1, int(order or 1))
            deriv = sp.diff(expr, var, n)
            steps = [
                f"Differentiate ${_latex(expr)}$ with respect to ${variable}$" + (f" ({n} times)" if n > 1 else "") + ".",
                f"Applying SymPy `diff`: $\\dfrac{{d^{n} }}{{d {variable}^{n}}} {_latex(expr)} = {_latex(deriv)}$",
            ]
            return _fmt_result(expression, f"diff (order {n})", deriv, steps)

        if operation == "integrate":
            if lower is not None and upper is not None and lower != "" and upper != "":
                a = _parse(lower)
                b = _parse(upper)
                if a is None or b is None:
                    return {"valid": False, "error": "Could not parse integration bounds."}
                result = sp.integrate(expr, (var, a, b))
                steps = [
                    f"Definite integral: $\\int_{{{_latex(a)}}}^{{{_latex(b)}}} {_latex(expr)}\\, d{variable}$",
                    f"SymPy result: ${_latex(result)}$",
                    f"Numerical value: {sp.N(result)}",
                ]
            else:
                result = sp.integrate(expr, var)
                steps = [
                    f"Indefinite integral: $\\int {_latex(expr)}\\, d{variable}$",
                    f"SymPy result: ${_latex(result)} + C$",
                ]
            return _fmt_result(expression, "integrate", result, steps)

        if operation == "factor":
            result = sp.factor(expr)
            return _fmt_result(expression, "factor", result, [
                f"Original: ${_latex(expr)}$",
                f"Factored: ${_latex(result)}$",
            ])

        if operation == "expand":
            result = sp.expand(expr)
            return _fmt_result(expression, "expand", result, [
                f"Original: ${_latex(expr)}$",
                f"Expanded: ${_latex(result)}$",
            ])

        if operation == "simplify":
            result = sp.simplify(expr)
            return _fmt_result(expression, "simplify", result, [
                f"Original: ${_latex(expr)}$",
                f"Simplified: ${_latex(result)}$",
            ])

        if operation == "limit":
            point_str = lower or "0"
            pt = _parse(point_str)
            if pt is None:
                return {"valid": False, "error": f"Could not parse limit point: {point_str!r}"}
            result = sp.limit(expr, var, pt)
            return _fmt_result(expression, "limit", result, [
                f"$\\lim_{{{variable} \\to {_latex(pt)}}} {_latex(expr)} = {_latex(result)}$",
            ])

        if operation == "series":
            point_str = lower or "0"
            n = max(2, int(order or 6))
            pt = _parse(point_str)
            if pt is None:
                return {"valid": False, "error": f"Could not parse expansion point: {point_str!r}"}
            result = sp.series(expr, var, pt, n).removeO()
            return _fmt_result(expression, f"series (order {n})", result, [
                f"Taylor series of ${_latex(expr)}$ around ${variable} = {_latex(pt)}$ to order {n}:",
                f"${_latex(result)}$",
            ])

        return {"valid": False, "error": f"Unknown operation: {operation!r}"}

    except Exception as e:
        return {"valid": False, "error": f"SymPy could not complete this operation: {e}"}
