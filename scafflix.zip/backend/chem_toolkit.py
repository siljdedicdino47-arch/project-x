"""
Cheminformatics toolkit for Scafflix — all real RDKit computation.

Provides: 2D structure depiction (SVG), molecular similarity (Tanimoto over
Morgan fingerprints), substructure search (SMARTS), Murcko scaffold extraction,
and simple analog enumeration (R-group / functional-group swaps).

Nothing here needs an API key or external service — it's pure local chemistry.
"""
from functools import lru_cache
from typing import List, Dict, Any, Optional

from rdkit import Chem
from rdkit.Chem import AllChem, Draw, DataStructs
from rdkit.Chem.Scaffolds import MurckoScaffold
from rdkit.Chem.Draw import rdMolDraw2D


def _mol_or_none(smiles: str):
    if not smiles or not isinstance(smiles, str):
        return None
    return Chem.MolFromSmiles(smiles.strip())


@lru_cache(maxsize=512)
def _depict_cached(canonical: str, width: int, height: int) -> str:
    """Render is keyed on canonical SMILES so 'CCO' and 'OCC' share one cache slot."""
    mol = Chem.MolFromSmiles(canonical)
    AllChem.Compute2DCoords(mol)
    drawer = rdMolDraw2D.MolDraw2DSVG(width, height)
    opts = drawer.drawOptions()
    opts.clearBackground = False
    drawer.DrawMolecule(mol)
    drawer.FinishDrawing()
    return drawer.GetDrawingText()


def depict_svg(smiles: str, width: int = 320, height: int = 240) -> Dict[str, Any]:
    """Render a molecule to a 2D SVG string the frontend can drop straight into the DOM."""
    mol = _mol_or_none(smiles)
    if mol is None:
        return {"valid": False, "error": f"Invalid SMILES: '{smiles}'"}

    canonical = Chem.MolToSmiles(mol)
    svg = _depict_cached(canonical, width, height)
    return {
        "valid": True,
        "smiles": canonical,
        "svg": svg,
    }


@lru_cache(maxsize=1024)
def _fingerprint_cached(canonical: str):
    """Morgan FP cache keyed on canonical SMILES — avoids recomputing per library scan."""
    mol = Chem.MolFromSmiles(canonical)
    return AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=2048)


def _fingerprint(mol):
    return _fingerprint_cached(Chem.MolToSmiles(mol))


def similarity_search(query_smiles: str, library: List[Dict[str, str]], top_k: int = 10) -> Dict[str, Any]:
    """
    Rank a compound library by Tanimoto similarity to a query molecule.
    `library` is a list of {name, smiles}. Returns ranked hits with scores 0–1.
    """
    query = _mol_or_none(query_smiles)
    if query is None:
        return {"valid": False, "error": f"Invalid query SMILES: '{query_smiles}'"}

    q_fp = _fingerprint(query)
    hits = []
    for entry in library:
        mol = _mol_or_none(entry.get("smiles", ""))
        if mol is None:
            continue
        score = DataStructs.TanimotoSimilarity(q_fp, _fingerprint(mol))
        hits.append({
            "name": entry.get("name", "Unnamed"),
            "smiles": Chem.MolToSmiles(mol),
            "similarity": round(score, 3),
        })

    hits.sort(key=lambda h: h["similarity"], reverse=True)
    return {
        "valid": True,
        "query": Chem.MolToSmiles(query),
        "hits": hits[:top_k],
        "searched": len(hits),
    }


def substructure_search(pattern_smarts: str, library: List[Dict[str, str]]) -> Dict[str, Any]:
    """
    Return every library compound containing a substructure pattern (SMARTS or SMILES).
    """
    pattern = Chem.MolFromSmarts(pattern_smarts) or Chem.MolFromSmiles(pattern_smarts)
    if pattern is None:
        return {"valid": False, "error": f"Could not parse pattern: '{pattern_smarts}'"}

    matches = []
    for entry in library:
        mol = _mol_or_none(entry.get("smiles", ""))
        if mol is None:
            continue
        if mol.HasSubstructMatch(pattern):
            matches.append({
                "name": entry.get("name", "Unnamed"),
                "smiles": Chem.MolToSmiles(mol),
            })

    return {
        "valid": True,
        "pattern": pattern_smarts,
        "matches": matches,
        "match_count": len(matches),
        "searched": len(library),
    }


def scaffold_analysis(smiles: str) -> Dict[str, Any]:
    """
    Extract the Bemis–Murcko scaffold (ring systems + linkers) and the generic
    (atom-type-flattened) framework. This is how you group an analog series.
    """
    mol = _mol_or_none(smiles)
    if mol is None:
        return {"valid": False, "error": f"Invalid SMILES: '{smiles}'"}

    scaffold = MurckoScaffold.GetScaffoldForMol(mol)
    generic = MurckoScaffold.MakeScaffoldGeneric(scaffold) if scaffold.GetNumAtoms() else scaffold

    return {
        "valid": True,
        "smiles": Chem.MolToSmiles(mol),
        "scaffold": Chem.MolToSmiles(scaffold),
        "generic_scaffold": Chem.MolToSmiles(generic),
        "ring_count": Chem.rdMolDescriptors.CalcNumRings(mol),
    }


# A small palette of common medicinal-chemistry R-group substitutions. This is a
# teaching-grade analog generator — it swaps terminal groups to show the idea of
# an analog series, not a validated enumeration engine.
_ANALOG_SWAPS = [
    ("[cH:1]", "[c:1]F", "aromatic H → F"),
    ("[cH:1]", "[c:1]Cl", "aromatic H → Cl"),
    ("[cH:1]", "[c:1]C", "aromatic H → CH3"),
    ("[cH:1]", "[c:1]OC", "aromatic H → OMe"),
    ("[CH3:1]", "[CH2:1]F", "methyl → fluoromethyl"),
]


def generate_analogs(smiles: str, max_analogs: int = 8) -> Dict[str, Any]:
    """
    Enumerate simple analogs by applying single R-group substitutions. Returns
    unique, valid, novel structures (excluding the input itself).
    """
    mol = _mol_or_none(smiles)
    if mol is None:
        return {"valid": False, "error": f"Invalid SMILES: '{smiles}'"}

    parent_canonical = Chem.MolToSmiles(mol)
    seen = {parent_canonical}
    analogs = []

    for smarts_in, smarts_out, label in _ANALOG_SWAPS:
        rxn = AllChem.ReactionFromSmarts(f"{smarts_in}>>{smarts_out}")
        if rxn is None:
            continue
        try:
            products = rxn.RunReactants((mol,))
        except Exception:
            continue
        for product_set in products:
            for prod in product_set:
                try:
                    Chem.SanitizeMol(prod)
                except Exception:
                    continue
                canonical = Chem.MolToSmiles(prod)
                if canonical not in seen:
                    seen.add(canonical)
                    analogs.append({"smiles": canonical, "modification": label})
                if len(analogs) >= max_analogs:
                    break
            if len(analogs) >= max_analogs:
                break
        if len(analogs) >= max_analogs:
            break

    return {
        "valid": True,
        "parent": parent_canonical,
        "analogs": analogs,
        "count": len(analogs),
    }
