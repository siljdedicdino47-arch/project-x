"""
Study tool: mechanism explorer.

Uses an LLM (Claude) to produce a *structured* mechanism as a list of steps —
each with reactant/product SMILES and a natural-language arrow-pushing
description. RDKit then validates every SMILES and renders each intermediate.

Deliberately honest:
- Requires a real Anthropic key. No key → no mechanism (never a fake diagram).
- The LLM is forced through a tool schema; we do not free-form parse prose.
- Any step whose SMILES RDKit cannot parse is flagged, not silently drawn.
- The response carries a `caveat` field: this is LLM-generated pedagogy and
  must be verified against a textbook or primary literature. We do not claim
  the mechanism is experimentally validated.
"""
from typing import Dict, Any, List, Optional

from rdkit import Chem

from backend.chembrain import get_client, call_claude_messages
from backend.chem_toolkit import depict_svg


MECHANISM_TOOL = {
    "name": "submit_mechanism",
    "description": (
        "Return the mechanism as a structured object. All molecule fields MUST be "
        "valid SMILES strings that RDKit can parse. Do not include reaction arrows "
        "inside SMILES — put reactant and product SMILES in separate arrays. Provide "
        "a plain-English arrow-pushing description referring to atoms by common names "
        "(e.g. 'the carbonyl carbon', 'the nitrogen lone pair')."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "reaction_name": {
                "type": "string",
                "description": "Named reaction if applicable, otherwise a short descriptive title."
            },
            "overview": {
                "type": "string",
                "description": "One-paragraph plain-English summary of the mechanism."
            },
            "steps": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "index": {"type": "integer"},
                        "title": {"type": "string"},
                        "reactants": {
                            "type": "array",
                            "items": {"type": "string", "description": "A single molecule SMILES"},
                        },
                        "products": {
                            "type": "array",
                            "items": {"type": "string", "description": "A single molecule SMILES"},
                        },
                        "arrow_pushing": {
                            "type": "string",
                            "description": (
                                "Curved-arrow electron-pushing description in words. "
                                "Reference bonds and atoms so a student can draw the arrows themselves."
                            ),
                        },
                        "notes": {"type": "string"},
                    },
                    "required": ["index", "title", "reactants", "products", "arrow_pushing"],
                },
            },
            "principles": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Underlying principles or rules the student should remember (e.g. 'Markovnikov', 'Zaitsev', 'Woodward-Hoffmann')."
            },
            "pitfalls": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Common student mistakes on this mechanism."
            },
        },
        "required": ["reaction_name", "overview", "steps"],
    },
}


SYSTEM_PROMPT_MECHANISM = """You are ChemBrain Study, a mechanism tutor for organic chemistry students.

RULES:
1. Submit your answer ONLY via the `submit_mechanism` tool. Never write freeform prose in the assistant channel — the app cannot render it.
2. Every SMILES string you output MUST be valid and parseable by RDKit. Prefer canonical forms.
3. Break the mechanism into the smallest instructive steps: bond formation, bond breaking, proton transfers, resonance stabilization. Each step goes in its own item.
4. In `arrow_pushing`, describe every curved arrow in words: which lone pair or π bond attacks which atom or bond, and where the electrons end up. Use words like "the carbonyl π bond", "the lone pair on nitrogen", "the C–H σ bond on the α-carbon" — not generic pronouns.
5. Do NOT invent literature citations. If you know a named reaction, put that in `reaction_name`. If you know a governing rule, put it in `principles`. Do not fabricate PMIDs.
6. If the question is not a reaction/mechanism question, respond with a single step whose `title` is "Not a mechanism" and explain briefly in `arrow_pushing`.
"""


def _sanitize_smiles(smi: str) -> Optional[str]:
    """Return canonical SMILES if RDKit accepts it, else None."""
    if not smi or not isinstance(smi, str):
        return None
    mol = Chem.MolFromSmiles(smi.strip())
    if mol is None:
        return None
    return Chem.MolToSmiles(mol)


def _decorate_step(step: Dict[str, Any]) -> Dict[str, Any]:
    """Validate every SMILES in a step and attach depiction SVGs."""
    def render_side(smiles_list: List[str]) -> List[Dict[str, Any]]:
        rendered = []
        for raw in smiles_list or []:
            canonical = _sanitize_smiles(raw)
            if canonical is None:
                rendered.append({
                    "smiles_input": raw,
                    "valid": False,
                    "error": "RDKit could not parse this SMILES.",
                })
                continue
            depict = depict_svg(canonical)
            rendered.append({
                "smiles_input": raw,
                "smiles": canonical,
                "valid": True,
                "svg": depict.get("svg") if depict.get("valid") else None,
            })
        return rendered

    return {
        "index": step.get("index"),
        "title": step.get("title", "").strip(),
        "reactants": render_side(step.get("reactants", [])),
        "products": render_side(step.get("products", [])),
        "arrow_pushing": step.get("arrow_pushing", "").strip(),
        "notes": (step.get("notes") or "").strip(),
    }


def study_mechanism(question: str, api_key_override: Optional[str] = None) -> Dict[str, Any]:
    q = (question or "").strip()
    if not q:
        return {"valid": False, "error": "Please enter a mechanism or synthesis question."}

    client = get_client(api_key_override)
    if client is None:
        return {
            "valid": False,
            "needs_key": True,
            "error": (
                "The Mechanism Explorer requires an Anthropic API key. "
                "Enter one in the header (session-only) or set ANTHROPIC_API_KEY in backend/.env."
            ),
        }

    messages = [{"role": "user", "content": q}]
    try:
        # Reuse the model fallback ladder from chembrain, but force the tool call.
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=3000,
            system=SYSTEM_PROMPT_MECHANISM,
            tools=[MECHANISM_TOOL],
            tool_choice={"type": "tool", "name": "submit_mechanism"},
            messages=messages,
        )
    except Exception as e:
        return {"valid": False, "error": f"LLM error: {e}"}

    payload = None
    for block in response.content:
        if getattr(block, "type", None) == "tool_use" and block.name == "submit_mechanism":
            payload = block.input
            break

    if not payload:
        return {"valid": False, "error": "LLM did not return a structured mechanism."}

    steps_raw = payload.get("steps") or []
    steps_decorated = [_decorate_step(s) for s in steps_raw]

    # Compute a coarse "how much of this parses cleanly" indicator, so the UI can
    # warn honestly if the model produced invalid SMILES anywhere.
    total_mols = sum(len(s["reactants"]) + len(s["products"]) for s in steps_decorated)
    valid_mols = sum(
        sum(1 for m in s["reactants"] if m.get("valid"))
        + sum(1 for m in s["products"] if m.get("valid"))
        for s in steps_decorated
    )

    return {
        "valid": True,
        "question": q,
        "reaction_name": (payload.get("reaction_name") or "").strip(),
        "overview": (payload.get("overview") or "").strip(),
        "steps": steps_decorated,
        "principles": [p for p in (payload.get("principles") or []) if p],
        "pitfalls": [p for p in (payload.get("pitfalls") or []) if p],
        "smiles_validation": {
            "total": total_mols,
            "valid": valid_mols,
        },
        "caveat": (
            "LLM-generated pedagogy — verify against a textbook (Clayden, Vollhardt) "
            "or the primary literature before relying on it for exam or research work."
        ),
    }
