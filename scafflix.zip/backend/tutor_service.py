"""
Personal AI tutor service.

Takes a student's question plus a subject and grade level, prompts the LLM to
answer at the right depth, and returns text + optional worked-example structure.

Grounding rules (kept honest for pedagogy):
- The tutor is prompted to show work step-by-step, not just an answer.
- It's told never to invent citations or fabricated references.
- For math specifically, we recommend the client also run the /math/solve
  endpoint so the numerical/symbolic answer is checked against SymPy.
"""
from typing import List, Dict, Any, Optional

from backend.chembrain import get_client, call_claude_messages


GRADE_DESCRIPTIONS = {
    "g4-6":   "elementary school (US grade 4–6, ages 9–11). Use concrete examples, avoid algebraic notation unless necessary, and keep vocabulary simple. Explain any word longer than three syllables.",
    "g7-9":   "middle school (US grade 7–9, ages 12–14). Introductory algebra and pre-algebra are fair game. Explain new vocabulary the first time it appears.",
    "g10-12": "high school (US grade 10–12, ages 15–18). Full algebra, calculus intro, high-school chemistry/physics/biology depth. Assume the student has seen basic concepts but may need reminders.",
    "uni-y1": "university year 1 (freshman). Calculus, gen chem, gen physics, intro biology, intro CS/discrete math. Use precise technical vocabulary and standard notation.",
    "uni-y2": "university year 2 (sophomore). Organic chemistry, multivariable calc, linear algebra, differential equations, physics 2 (E&M), molecular biology, data structures. Full technical rigor.",
}

SUBJECT_HINTS = {
    "math":      "Show every algebraic step. When you write an equation, write it in LaTeX between $$...$$ so the client renders it. Recommend the student cross-check numeric or symbolic answers via the Math workbench (SymPy).",
    "chemistry": "When a molecule is involved, mention its SMILES so the student can drop it into the ADMET, 3D structure, or Scaffold modules. For mechanisms, describe every arrow (which pair attacks which bond, where electrons end up) — like Clayden.",
    "physics":   "Show every equation with units in LaTeX. Draw free-body reasoning in words before jumping to a formula. Sanity-check the final answer's units.",
    "biology":   "Prefer mechanism over memorization: explain WHY a pathway/process works, not just its name. Cite molecular players by name.",
    "cs":        "Show code in the language the student names, else Python. Discuss complexity (big-O) for algorithms. For data structures, sketch invariants.",
    "english":   "For essay/analysis help, ask what argument the student is trying to make before critiquing. Distinguish thesis, evidence, and warrant.",
    "history":   "Ground claims in dates, actors, and primary sources when possible. Distinguish between what historians agree on vs. what is contested.",
    "general":   "Ask a clarifying question if the subject is ambiguous.",
}


def _system_prompt(subject: str, grade: str) -> str:
    subj_hint = SUBJECT_HINTS.get(subject, SUBJECT_HINTS["general"])
    grade_desc = GRADE_DESCRIPTIONS.get(grade, GRADE_DESCRIPTIONS["uni-y1"])
    return f"""You are a patient personal tutor. You are speaking with a student at the level of {grade_desc}

Subject: {subject}. {subj_hint}

TEACHING PRINCIPLES:
1. Show your work. Never jump straight to an answer for a math/science problem — walk through the reasoning.
2. If the student's question is unclear, ask ONE clarifying question first.
3. When you introduce a new term, define it briefly the first time.
4. Prefer worked examples over abstract rules.
5. Do not invent references, statistics, papers, or historical facts. If you are not sure, say "I'm not sure" and suggest how to check.
6. If a question is a homework problem, help the student learn — give hints and check-your-understanding prompts, not just the answer. Only give the final answer when the student explicitly asks for it after working through hints.
7. If asked about something outside the current subject, answer briefly and offer to switch subjects.
8. Keep replies focused; use short paragraphs and lists over walls of text.

Reply in plain text with LaTeX equations wrapped in $$...$$ where they clarify. Never fabricate citations."""


def tutor_answer(
    question: str,
    subject: str,
    grade: str,
    history: List[Dict[str, Any]],
    api_key_override: Optional[str] = None,
) -> Dict[str, Any]:
    q = (question or "").strip()
    if not q:
        return {"valid": False, "error": "Please enter a question."}

    client = get_client(api_key_override)
    if client is None:
        return {
            "valid": False,
            "needs_key": True,
            "error": (
                "The AI tutor needs an Anthropic API key. Paste one in the header "
                "(session-only), or work in Math (SymPy) or Chemistry (RDKit) — "
                "those subjects have real computational tools that don't need a key."
            ),
        }

    formatted_messages = []
    for msg in (history or [])[-20:]:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if role in ["user", "assistant"] and content:
            formatted_messages.append({"role": role, "content": content})
    formatted_messages.append({"role": "user", "content": q})

    try:
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=2000,
            system=_system_prompt(subject, grade),
            messages=formatted_messages,
        )
        text = "\n".join([b.text for b in response.content if hasattr(b, "text")])
    except Exception as e:
        return {"valid": False, "error": f"LLM error: {e}"}

    return {
        "valid": True,
        "response": text,
        "subject": subject,
        "grade": grade,
    }
