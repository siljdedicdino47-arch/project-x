"""
Pharmacophore feature extraction (RDKit) + shape/O3A overlay.

Uses RDKit's ChemicalFeatures with the standard BaseFeatures FDef to enumerate
H-bond donors, H-bond acceptors, aromatic ring centers, and hydrophobes for a
molecule. Nothing invented — the feature dictionary is RDKit's own.

Also exposes an O3A shape overlay: given a query SMILES and a reference SMILES,
embed both to 3D and compute an Open3DAlign score. Real geometry, real score.
"""
import os
from typing import Dict, Any, List

from rdkit import Chem, RDConfig
from rdkit.Chem import AllChem, ChemicalFeatures


FDEF_PATH = os.path.join(RDConfig.RDDataDir, "BaseFeatures.fdef")
_FEATURE_FACTORY = ChemicalFeatures.BuildFeatureFactory(FDEF_PATH)


def _mol_or_none(smiles: str):
    if not smiles:
        return None
    return Chem.MolFromSmiles(smiles.strip())


def extract_pharmacophore(smiles: str) -> Dict[str, Any]:
    mol = _mol_or_none(smiles)
    if mol is None:
        return {"valid": False, "error": f"Invalid SMILES: '{smiles}'"}
    features = _FEATURE_FACTORY.GetFeaturesForMol(mol)

    out: List[Dict[str, Any]] = []
    for feat in features:
        out.append({
            "family": feat.GetFamily(),
            "type": feat.GetType(),
            "atom_indices": list(feat.GetAtomIds()),
        })

    counts: Dict[str, int] = {}
    for f in out:
        counts[f["family"]] = counts.get(f["family"], 0) + 1

    return {
        "valid": True,
        "smiles": Chem.MolToSmiles(mol),
        "features": out,
        "counts": counts,
    }


def shape_overlay(query_smiles: str, ref_smiles: str) -> Dict[str, Any]:
    q = _mol_or_none(query_smiles)
    r = _mol_or_none(ref_smiles)
    if q is None:
        return {"valid": False, "error": f"Invalid query SMILES: {query_smiles!r}"}
    if r is None:
        return {"valid": False, "error": f"Invalid reference SMILES: {ref_smiles!r}"}

    qH = Chem.AddHs(q)
    rH = Chem.AddHs(r)
    params = AllChem.ETKDGv3()
    params.randomSeed = 0xBEEF
    if AllChem.EmbedMolecule(qH, params) != 0 or AllChem.EmbedMolecule(rH, params) != 0:
        return {"valid": False, "error": "3D embedding failed for query or reference."}
    try:
        AllChem.MMFFOptimizeMolecule(qH, maxIters=200)
        AllChem.MMFFOptimizeMolecule(rH, maxIters=200)
    except Exception:
        AllChem.UFFOptimizeMolecule(qH, maxIters=200)
        AllChem.UFFOptimizeMolecule(rH, maxIters=200)

    try:
        o3a = AllChem.GetO3A(qH, rH)
        rmsd = float(o3a.Align())
        score = float(o3a.Score())
    except Exception as e:
        return {"valid": False, "error": f"O3A alignment failed: {e}"}

    return {
        "valid": True,
        "query_smiles": Chem.MolToSmiles(q),
        "reference_smiles": Chem.MolToSmiles(r),
        "rmsd_A": round(rmsd, 3),
        "o3a_score": round(score, 2),
        "query_molblock": Chem.MolToMolBlock(qH),
        "reference_molblock": Chem.MolToMolBlock(rH),
    }
