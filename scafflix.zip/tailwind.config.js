/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#F0F1EB',
        surface: '#FBFBF7',
        'surface-inset': '#F5F6F0',
        ink: {
          DEFAULT: '#161C19',
          muted: '#54605A',
          faint: '#8A938D',
        },
        line: {
          DEFAULT: '#DADDD3',
          soft: '#E7E9E0',
          strong: '#B9BEB2',
        },
        accent: {
          DEFAULT: '#3D6B63',
          soft: '#E3ECE8',
          strong: '#20423C',
        },
        flag: {
          good: '#2F7D5A',
          'good-soft': '#E4F1EA',
          warn: '#A9762E',
          'warn-soft': '#F5EBDA',
          risk: '#AE3B3B',
          'risk-soft': '#F6E4E2',
        },
      },
      fontFamily: {
        sans: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
        serif: ['"Instrument Serif"', 'ui-serif', 'Georgia', 'serif'],
      },
      borderRadius: {
        sm: '3px',
        DEFAULT: '4px',
      },
      letterSpacing: {
        wider: '0.08em',
        widest: '0.14em',
      },
      fontSize: {
        micro: ['10px', { lineHeight: '1.2' }],
      },
    },
  },
  plugins: [],
};
