# CLAUDE.md — Scafflix

Context for Claude Code working in this repo. Read this before making changes.

## What this is

Scafflix is a cheminformatics workbench for early-stage drug discovery — the
affordable, chat-and-tools alternative to enterprise suites like Schrödinger.
A user pastes a molecule (SMILES) or asks a question in plain English, and the
app answers with **real chemistry tools and real PubMed papers**, not guessed
chat. The organizing metaphor is a module workbench (Analyze / Search / Design /
Simulate), the same shape as Schrödinger's Maestro but chat-first and priced for
students, academic labs, and tiny biotechs.

This is a **prototype**, not a production SaaS. It deliberately has no auth, no
billing, and no persistent database yet. Keep that scope unless asked to expand
it.

## The single most important rule in this codebase

**Never fake a scientific result.** Every number the app shows must come from a
real computation or a real retrieved source. If a capability can't genuinely run
on a laptop (quantum chemistry, molecular dynamics), it is presented as a
clearly-labelled "planned module" tile that describes what it *would* do and
which engine it needs — it does not emit invented values. A fake result would
make every real result look untrustworthy. Preserve this behavior. When adding a
module, if you can't make it real, make it an honest roadmap tile instead.

Related grounding rules already enforced in `backend/chembrain.py`:
- Every factual claim from ChemBrain is source-labelled (`[PubMed: PMID …]`,
  `[Predicted: ADMET-AI]`, `[RDKit]`).
- LitScout answers cite **only** abstracts actually retrieved in that query —
  never the model's training data. Don't loosen this.

## Architecture

Three tiers, all talking over HTTP:

```
React + Vite + Tailwind (src/)          ← the website, port 5173
        │  fetch → http://localhost:8000
FastAPI (backend/)                       ← all API keys + external calls live here
        ├── RDKit / ADMET logic          (local compute)
        ├── PubMed E-utilities           (NCBI, no key needed)
        ├── Anthropic Claude API         (optional — see below)
        └── AutoDock Vina                (optional, docking)
```

There is also a standalone `streamlit_app.py` — the original single-file
prototype, kept for quick demos. It duplicates the backend logic inline. If you
change core chemistry behavior, consider whether both surfaces need the change;
usually the React+FastAPI path is the one to prioritize.

### No API key required

The app runs fully without an Anthropic key. Without one, ADMET, PubMed,
similarity, substructure, scaffold, analogs, and docking all still work (they're
RDKit/NCBI/Vina, not the LLM). The key only adds ChemBrain's conversational
synthesis layer. `checkHealth()` reports `anthropic_configured`; the UI shows
"direct tools" vs "conversational" accordingly. Don't add hard dependencies on
the key to any of the tool endpoints.

## File map

```
backend/
  main.py               FastAPI app + all route definitions
  admet_service.py      RDKit ADMET + Lipinski (predict_admet)
  pubmed_service.py     PubMed esearch/efetch (search_pubmed_raw)
  chembrain.py          Claude tool-calling loop + literature synthesis + system prompt
  chem_toolkit.py       depict_svg, similarity_search, substructure_search,
                        scaffold_analysis, generate_analogs   (all pure RDKit)
  advanced_modules.py   docking_status, run_docking (real Vina),
                        quantum_chemistry, molecular_dynamics (honest roadmap tiles)

src/
  App.tsx               Module-rail workbench shell; owns active-module state + LIBRARY
  services/api.ts       Every backend call, typed. Add new endpoints' clients here.
  components/
    panels.tsx          One panel component per module (AdmetPanel, SimilarityPanel, …)
    AdmetCard.tsx       ADMET readout table (instrument-style, flag dots)
    LiteratureCard.tsx  PubMed reference list
    MoleculeView.tsx    Fetches an SVG from /depict and renders it

streamlit_app.py        Standalone prototype (mirrors backend logic inline)
requirements.txt        Python deps (vina/meeko optional, bottom of file)
package.json            Frontend deps
```

## Endpoints (backend/main.py)

| Method | Path | Purpose | Real? |
|---|---|---|---|
| GET  | /health | status + anthropic_configured | — |
| POST | /admet | ADMET + Lipinski for one SMILES | yes |
| GET  | /literature?q= | PubMed search + synthesis | yes |
| POST | /chat | ChemBrain tool-calling (needs key for full mode) | yes |
| POST | /depict | SMILES → 2D SVG | yes |
| POST | /similarity | Tanimoto rank against a library | yes |
| POST | /substructure | SMARTS/SMILES pattern match | yes |
| POST | /scaffold | Murcko + generic scaffold | yes |
| POST | /analogs | R-group-swap analog enumeration | yes |
| GET  | /docking/status | is Vina installed | yes |
| POST | /docking/run | real Vina run (needs receptor+box) | yes* |
| POST | /quantum | roadmap tile payload | planned |
| POST | /dynamics | roadmap tile payload | planned |

\* `/docking/run` returns a structured `needs_setup` response until given a
prepared receptor PDBQT + search box — it never invents binding scores.

## Running locally

Backend (terminal 1):
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.main:app --reload --port 8000
```

Frontend (terminal 2):
```bash
npm install
npm run dev            # http://localhost:5173
```

Streamlit alternative:
```bash
streamlit run streamlit_app.py
```

To enable docking: `pip install vina meeko` (already in requirements; the
docking panel degrades gracefully if absent).

## Conventions

**Backend**
- Every tool function returns a plain dict with a `valid` boolean (or a
  `needs_setup`/`live`/`ready` flag for the module-status shapes). Callers check
  the flag; endpoints map failure to HTTP 400.
- Validate SMILES with RDKit (`Chem.MolFromSmiles`) before any computation.
  Return a clear error string on invalid input — don't raise raw exceptions to
  the client.
- No secrets in code. `ANTHROPIC_API_KEY` / `NCBI_API_KEY` come from env / .env
  only. `.env` is gitignored; never commit one.
- Pydantic models for request bodies. Watch for duplicate model names — a past
  bug had two `SimilarityRequest` classes silently shadowing each other and
  breaking a route. One model per name.

**Frontend**
- Add every new backend call to `src/services/api.ts` with a typed return, then
  build a panel in `components/panels.tsx` and register it in `App.tsx`'s
  `MODULES` array + `renderPanel()` switch.
- Design language is deliberate and must stay non-generic. Tokens live in
  `tailwind.config.js`: paper background, charcoal-green `ink`, one muted teal
  `accent`, and `flag-good/warn/risk` for property status. IBM Plex Sans for UI,
  IBM Plex Mono for data (SMILES, PMIDs, values). Avoid the generic-AI look:
  no gradient avatar blobs, no indigo→cyan buttons, no identical rounded cards
  with soft shadows everywhere. One bold element per view; keep the rest quiet.
- No `localStorage`/`sessionStorage` — not supported in the artifact environment
  and not needed here; keep state in React.

## Real vs planned — keep this honest

Live modules (real compute): ADMET, scaffold, similarity, substructure,
literature, analogs, docking (with receptor).

Planned tiles (intentionally not computing): quantum chemistry, molecular
dynamics. Their `live: false` payloads describe scope + engine + why-not-yet.
If asked to "make QM/MD work," the honest path is Psi4 (QM) and OpenMM+GPU (MD)
as real engines — not a faked output. Flag the compute/time cost before building.

**ORCA note:** ORCA is free for academic/personal use but its license forbids
redistribution and commercial use, so it must **not** be bundled into Scafflix
as a product feature or added to requirements. For a real product QM module,
use Psi4 (open-source). ORCA is fine only as a tool the founder runs personally.

## Analog generator caveat

`generate_analogs` in `chem_toolkit.py` does single R-group swaps from a small
fixed `_ANALOG_SWAPS` palette. It's a teaching-grade SAR starter, not a
validated enumeration engine. If you extend it, keep it labelled as such in the
UI; don't oversell it as lead optimization.

## Good next steps (roughly ordered)

1. Persist the compound library (currently a hardcoded `LIBRARY` in App.tsx) —
   start with SQLite in the backend, one table, no auth yet.
2. Let users add/remove compounds from the library in the UI, feeding
   similarity/substructure searches.
3. Wire `/docking/run` to a real end-to-end Vina run with a bundled sample
   receptor so the docking panel has a working demo path.
4. Add a 3D structure viewer (3Dmol.js or NGL) — the honest web-native answer to
   "can it do PyMOL." Real, and a good showcase.
5. Batch ADMET over the whole library with a sortable results table.
6. Only after the tool loop is validated: auth (Supabase), then billing (Stripe),
   per the original build spec. Don't build these early.

## What not to do

- Don't fake QM/MD/docking outputs to make a demo look complete.
- Don't bundle ORCA or any redistribution-restricted binary.
- Don't add auth/billing/multi-user infra before the core tools are solid.
- Don't let ChemBrain cite papers it wasn't given, or drop source labels.
- Don't reintroduce duplicate Pydantic model names or duplicate routes.
- Don't commit secrets or a real `.env`.
