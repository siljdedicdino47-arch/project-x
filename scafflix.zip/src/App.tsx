import { useState, useEffect, useCallback } from "react";
import { checkHealth, listLibrary, LibraryCompound } from "./services/api";
import { useActiveMolecule } from "./context/ActiveMolecule";
import { useStudySession, SUBJECTS, GRADES, Subject, Grade } from "./context/StudySession";
import {
  AdmetPanel,
  LiteraturePanel,
  SimilarityPanel,
  SubstructurePanel,
  ScaffoldPanel,
  AnalogPanel,
  DockingPanel,
  RoadmapPanel,
  Mol3DPanel,
  ChatPanel,
  LibraryPanel,
  BatchAdmetPanel,
  MechanismPanel,
  ProteinPanel,
  PharmacophorePanel,
  RetroPanel,
  TutorPanel,
  MathPanel,
  PracticePanel,
} from "./components/panels";

type ModuleId =
  // Learn
  | "tutor" | "math" | "practice" | "mechanism"
  // Assistant (chemistry chat)
  | "chembrain"
  // Chemistry — Analyze
  | "admet" | "batch_admet" | "scaffold" | "mol3d"
  // Chemistry — Structural bio
  | "protein"
  // Chemistry — Search
  | "similarity" | "substructure" | "literature"
  // Chemistry — Design
  | "analogs" | "pharmacophore" | "retro"
  // Chemistry — Simulate
  | "docking" | "quantum" | "dynamics"
  // Library
  | "library";

interface ModuleDef {
  id: ModuleId;
  label: string;
  group: string;
  live: boolean;
  needsLLM?: boolean;
}

const MODULES: ModuleDef[] = [
  { id: "tutor",         label: "AI Tutor",             group: "Learn",           live: true, needsLLM: true },
  { id: "math",          label: "Math workbench",       group: "Learn",           live: true },
  { id: "practice",      label: "Practice problems",    group: "Learn",           live: true, needsLLM: true },
  { id: "mechanism",     label: "Mechanism Explorer",   group: "Learn",           live: true, needsLLM: true },

  { id: "chembrain",     label: "ChemBrain chat",       group: "Chemistry Lab",   live: true },
  { id: "admet",         label: "ADMET",                group: "Chemistry Lab",   live: true },
  { id: "batch_admet",   label: "Batch ADMET",          group: "Chemistry Lab",   live: true },
  { id: "scaffold",      label: "Scaffold",             group: "Chemistry Lab",   live: true },
  { id: "mol3d",         label: "3D structure",         group: "Chemistry Lab",   live: true },
  { id: "protein",       label: "Protein viewer",       group: "Chemistry Lab",   live: true },
  { id: "similarity",    label: "Similarity",           group: "Chemistry Lab",   live: true },
  { id: "substructure",  label: "Substructure",         group: "Chemistry Lab",   live: true },
  { id: "literature",    label: "Literature",           group: "Chemistry Lab",   live: true },
  { id: "analogs",       label: "Analog generator",     group: "Chemistry Lab",   live: true },
  { id: "pharmacophore", label: "Pharmacophore",        group: "Chemistry Lab",   live: true },
  { id: "retro",         label: "Retrosynthesis",       group: "Chemistry Lab",   live: true },
  { id: "docking",       label: "Docking",              group: "Chemistry Lab",   live: true },
  { id: "quantum",       label: "Quantum chemistry",    group: "Chemistry Lab",   live: false },
  { id: "dynamics",      label: "Molecular dynamics",   group: "Chemistry Lab",   live: false },

  { id: "library",       label: "Saved compounds",      group: "Library",         live: true },
];

const GROUPS = ["Learn", "Chemistry Lab", "Library"];

export default function App() {
  const [active, setActive] = useState<ModuleId>("tutor");
  const [serverStatus, setServerStatus] = useState<"connected" | "offline" | "checking">("checking");
  const [anthropicConfigured, setAnthropicConfigured] = useState(false);
  const [library, setLibrary] = useState<LibraryCompound[]>([]);
  const [apiKey, setApiKey] = useState<string>("");
  const [showKeyPanel, setShowKeyPanel] = useState(false);
  const { registerNavigator } = useActiveMolecule();
  const { subject, grade, setSubject, setGrade } = useStudySession();

  useEffect(() => {
    registerNavigator((moduleId: string) => setActive(moduleId as ModuleId));
  }, [registerNavigator]);

  const refreshLibrary = useCallback(async () => {
    try {
      setLibrary(await listLibrary());
    } catch {
      setLibrary([]);
    }
  }, []);

  useEffect(() => {
    checkHealth().then((res) => {
      if (res.status === "ok") {
        setServerStatus("connected");
        setAnthropicConfigured(res.anthropic_configured);
        refreshLibrary();
      } else {
        setServerStatus("offline");
      }
    });
  }, [refreshLibrary]);

  const llmActive = anthropicConfigured || !!apiKey;

  const renderPanel = () => {
    switch (active) {
      case "tutor":        return <TutorPanel apiKey={apiKey} anthropicConfigured={anthropicConfigured} />;
      case "math":         return <MathPanel />;
      case "practice":     return <PracticePanel apiKey={apiKey} anthropicConfigured={anthropicConfigured} />;
      case "mechanism":    return <MechanismPanel anthropicConfigured={anthropicConfigured} apiKey={apiKey} />;
      case "chembrain":    return <ChatPanel anthropicConfigured={anthropicConfigured} apiKey={apiKey} />;
      case "admet":        return <AdmetPanel library={library} />;
      case "batch_admet":  return <BatchAdmetPanel compounds={library} />;
      case "literature":   return <LiteraturePanel />;
      case "similarity":   return <SimilarityPanel library={library} />;
      case "substructure": return <SubstructurePanel library={library} />;
      case "scaffold":     return <ScaffoldPanel />;
      case "analogs":      return <AnalogPanel />;
      case "mol3d":        return <Mol3DPanel library={library} />;
      case "protein":      return <ProteinPanel />;
      case "pharmacophore":return <PharmacophorePanel />;
      case "retro":        return <RetroPanel />;
      case "docking":      return <DockingPanel />;
      case "quantum":      return <RoadmapPanel kind="quantum" />;
      case "dynamics":     return <RoadmapPanel kind="dynamics" />;
      case "library":      return <LibraryPanel compounds={library} onChange={refreshLibrary} />;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-paper text-ink font-sans">
      {/* Top header — rebranded for tutoring, keeps the Chemistry Lab identity */}
      <header className="border-b border-line bg-surface">
        <div className="h-14 px-6 flex items-center justify-between">
          <div className="flex items-baseline gap-3">
            <div className="font-serif text-2xl leading-none tracking-tight text-ink">Scafflix</div>
            <div className="text-[11px] tracking-wider uppercase text-ink-faint">
              Personal AI tutor · with a working chemistry lab
            </div>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <SelectPill
              label="Subject"
              value={subject}
              onChange={(v) => setSubject(v as Subject)}
              options={SUBJECTS.map((s) => ({ value: s.id, label: s.label }))}
            />
            <SelectPill
              label="Grade"
              value={grade}
              onChange={(v) => setGrade(v as Grade)}
              options={GRADES.map((g) => ({ value: g.id, label: g.label }))}
            />
            <StatusPill label="Backend" value={serverStatus} good="connected" />
            <button
              onClick={() => setShowKeyPanel((v) => !v)}
              className="text-ink-muted hover:text-accent transition-colors"
              title="Session-only Anthropic API key. Never saved to disk."
            >
              {apiKey ? "Key set ✓" : anthropicConfigured ? "Env key" : "Set API key"}
            </button>
          </div>
        </div>
        {showKeyPanel && (
          <div className="px-6 pb-3 -mt-1">
            <div className="max-w-2xl border border-line rounded bg-surface-inset p-3">
              <div className="text-[11px] text-ink-muted mb-1.5">
                Anthropic API key · session-only, held in React state, never sent anywhere but your local backend, never written to disk.
              </div>
              <div className="flex gap-2">
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="sk-ant-…"
                  className="flex-1 bg-surface border border-line rounded px-3 py-1.5 text-sm font-mono focus:outline-none focus:border-accent"
                />
                {apiKey && (
                  <button onClick={() => setApiKey("")} className="px-3 py-1.5 border border-line rounded text-xs text-ink-muted hover:text-flag-risk">Clear</button>
                )}
                <button onClick={() => setShowKeyPanel(false)} className="px-3 py-1.5 bg-ink text-paper rounded text-xs">Done</button>
              </div>
            </div>
          </div>
        )}
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Module rail */}
        <aside className="w-60 border-r border-line bg-surface-inset flex flex-col">
          <nav className="flex-1 overflow-y-auto thin-scroll px-3 py-5 space-y-5">
            {GROUPS.map((group) => {
              const items = MODULES.filter((m) => m.group === group);
              if (items.length === 0) return null;
              return (
                <div key={group}>
                  <div className="eyebrow px-2 mb-2">{group}</div>
                  {items.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setActive(m.id)}
                      className={`w-full text-left px-2 py-1.5 rounded-sm text-sm flex items-center justify-between group transition-colors ${
                        active === m.id
                          ? "bg-surface text-ink border-l-2 border-accent -ml-[2px] pl-[6px]"
                          : "text-ink-muted hover:text-ink hover:bg-surface/60"
                      }`}
                    >
                      <span className="truncate">{m.label}</span>
                      {!m.live && (
                        <span className="text-[9px] tracking-wider uppercase text-flag-warn">planned</span>
                      )}
                      {m.live && m.needsLLM && !llmActive && (
                        <span className="text-[9px] tracking-wider uppercase text-ink-faint" title="Requires an Anthropic key">needs key</span>
                      )}
                    </button>
                  ))}
                </div>
              );
            })}
          </nav>

          <div className="px-4 py-4 border-t border-line text-[11px] text-ink-faint">
            <div className="font-mono">SymPy · RDKit · PubMed · Vina</div>
            <div className="mt-1">Every answer is a real computation or a cited source.</div>
          </div>
        </aside>

        {/* Work area */}
        <main className="flex-1 overflow-y-auto thin-scroll grid-bg">
          <div className="px-8 py-8">
            {serverStatus === "offline" && (
              <div className="max-w-3xl mb-6 border border-flag-risk rounded px-4 py-3 text-sm text-flag-risk">
                Can't reach the backend on <span className="font-mono">http://localhost:8000</span>.
                Start it with <span className="font-mono">uvicorn backend.main:app --reload --port 8000</span>.
              </div>
            )}
            {renderPanel()}
          </div>
        </main>
      </div>
    </div>
  );
}

const SelectPill: React.FC<{ label: string; value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }> = ({ label, value, onChange, options }) => (
  <label className="flex items-center gap-1.5">
    <span className="text-ink-faint">{label}</span>
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="bg-surface-inset border border-line rounded px-2 py-1 text-[11px] focus:outline-none focus:border-accent text-ink"
    >
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </label>
);

const StatusPill: React.FC<{ label: string; value: string; good: string }> = ({ label, value, good }) => {
  const ok = value === good;
  const offline = value === "offline";
  const dotColor = offline ? "bg-flag-risk" : ok ? "bg-flag-good" : "bg-flag-warn";
  return (
    <div className="flex items-center gap-1.5">
      <span className={`inline-block w-1.5 h-1.5 rounded-full ${dotColor}`} />
      <span className="text-ink-faint">{label}</span>
      <span className="text-ink font-mono">{value}</span>
    </div>
  );
};
