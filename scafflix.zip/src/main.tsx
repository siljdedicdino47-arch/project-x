import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { ActiveMoleculeProvider } from './context/ActiveMolecule.tsx';
import { StudySessionProvider } from './context/StudySession.tsx';
import 'katex/dist/katex.min.css';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <StudySessionProvider>
      <ActiveMoleculeProvider>
        <App />
      </ActiveMoleculeProvider>
    </StudySessionProvider>
  </StrictMode>
);
