import React, { useState, useRef, useEffect } from "react";
import {
  sendChatMessage,
  ChatResponse,
  AdmetResponse,
  ReferenceItem,
  ChatToolData,
  ChatToolKind,
  SimilarityHit,
  LibraryCompound,
} from "../services/api";
import { AdmetCard } from "./AdmetCard";
import { LiteratureCard } from "./LiteratureCard";
import { MoleculeView } from "./MoleculeView";
import { Mol3DView } from "./Mol3DView";
import { Panel } from "./Panel";

type Turn = {
  role: "user" | "assistant";
  content: string;
  admet?: AdmetResponse | null;
  refs?: ReferenceItem[] | null;
  tool?: ChatToolKind | null;
  toolData?: ChatToolData | null;
};

interface Props {
  anthropicConfigured: boolean;
  apiKey: string;
}

const STARTERS = [
  "Predict ADMET for CC(=O)Oc1ccccc1C(=O)O",
  "Find compounds similar to CC(C)Cc1ccc(C(C)C(=O)O)cc1",
  "Which library compounds contain c1ccncc1 ?",
  "Scaffold of Cc1ccc(NC(=O)c2ccc(CN3CCN(C)CC3)cc2)cc1Nc1nccc(-c2cccnc2)n1",
  "Generate analogs of c1ccccc1C(=O)O",
  "Show 3D of CCO",
  "Search PubMed for KRAS G12C inhibitor selectivity",
  "Show the library",
  "Is docking ready?",
];

/** Renderer: similarity ranking with structure thumbnails. */
const SimilarityInline: React.FC<{ data: { hits: SimilarityHit[]; query: string } }> = ({ data }) => (
  <div className="mt-3 border border-line rounded bg-surface divide-y divide-line">
    {data.hits.map((h) => (
      <div key={h.name + h.smiles} className="px-3 py-2 flex items-center gap-3">
        <div className="w-[64px] flex-shrink-0"><MoleculeView smiles={h.smiles} size={64} /></div>
        <div className="min-w-0 flex-1">
          <div className="text-sm">{h.name}</div>
          <div className="text-[11px] text-ink-faint font-mono truncate">{h.smiles}</div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-20 h-1.5 bg-line rounded-full overflow-hidden">
            <div className="h-full bg-accent" style={{ width: `${h.similarity * 100}%` }} />
          </div>
          <span className="text-sm font-mono w-10 text-right">{h.similarity.toFixed(2)}</span>
        </div>
      </div>
    ))}
  </div>
);

/** Renderer: substructure matches with structure thumbnails. */
const SubstructureInline: React.FC<{ data: { matches: { name: string; smiles: string }[]; pattern: string } }> = ({ data }) => (
  <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-3">
    {data.matches.map((m) => (
      <div key={m.name + m.smiles}>
        <MoleculeView smiles={m.smiles} size={140} />
        <div className="text-xs mt-1">{m.name}</div>
      </div>
    ))}
  </div>
);

/** Renderer: scaffold triple. */
const ScaffoldInline: React.FC<{ data: { smiles: string; scaffold: string; generic_scaffold: string; ring_count: number } }> = ({ data }) => (
  <div className="mt-3 flex flex-wrap gap-6">
    <div>
      <div className="eyebrow mb-1">Molecule</div>
      <MoleculeView smiles={data.smiles} size={160} />
    </div>
    <div>
      <div className="eyebrow mb-1">Murcko scaffold</div>
      <MoleculeView smiles={data.scaffold} size={160} />
    </div>
    <div>
      <div className="eyebrow mb-1">Generic · {data.ring_count} ring(s)</div>
      <MoleculeView smiles={data.generic_scaffold} size={160} />
    </div>
  </div>
);

/** Renderer: analog grid. */
const AnalogsInline: React.FC<{ data: { parent: string; analogs: { smiles: string; modification: string }[] } }> = ({ data }) => (
  <div className="mt-3 space-y-3">
    <div className="text-xs text-ink-muted">Parent: <span className="font-mono">{data.parent}</span></div>
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {data.analogs.map((a, i) => (
        <div key={i}>
          <MoleculeView smiles={a.smiles} size={140} />
          <div className="text-[11px] text-ink-muted mt-1">{a.modification}</div>
        </div>
      ))}
    </div>
  </div>
);

/** Renderer: interactive 3D viewer inline. */
const Mol3DInline: React.FC<{ data: { smiles: string } }> = ({ data }) => (
  <div className="mt-3 max-w-md">
    <Mol3DView smiles={data.smiles} height={280} />
  </div>
);

/** Renderer: library listing with structure thumbnails. */
const LibraryInline: React.FC<{ data: { compounds: LibraryCompound[] } }> = ({ data }) => (
  <div className="mt-3 border border-line rounded bg-surface divide-y divide-line">
    {data.compounds.map((c) => (
      <div key={c.id} className="px-3 py-2 flex items-center gap-3">
        <div className="w-[64px] flex-shrink-0"><MoleculeView smiles={c.smiles} size={64} /></div>
        <div className="min-w-0 flex-1">
          <div className="text-sm">
            {c.name} {c.tag && <span className="text-[11px] text-ink-muted">· {c.tag}</span>}
          </div>
          <div className="text-[11px] text-ink-faint font-mono truncate">{c.canonical_smiles}</div>
        </div>
      </div>
    ))}
  </div>
);

/** Renderer: docking status. */
const DockingInline: React.FC<{ data: { ready: boolean; engine: string; detail: string } }> = ({ data }) => (
  <div className="mt-3 border border-line rounded bg-surface p-3 text-sm">
    <div className="flex items-center gap-2 mb-1.5">
      <span className={`inline-block w-1.5 h-1.5 rounded-full ${data.ready ? "bg-flag-good" : "bg-flag-warn"}`} />
      <span>{data.engine} — {data.ready ? "ready" : "not detected"}</span>
    </div>
    <div className="text-ink-muted text-xs">{data.detail}</div>
  </div>
);

const renderToolInline = (td: ChatToolData) => {
  const d = td.data as never;
  switch (td.tool) {
    case "similarity":   return <SimilarityInline data={d} />;
    case "substructure": return <SubstructureInline data={d} />;
    case "scaffold":     return <ScaffoldInline data={d} />;
    case "analogs":      return <AnalogsInline data={d} />;
    case "mol3d":        return <Mol3DInline data={d} />;
    case "library":      return <LibraryInline data={d} />;
    case "docking":      return <DockingInline data={d} />;
    default:             return null;
  }
};

export const ChatPanel: React.FC<Props> = ({ anthropicConfigured, apiKey }) => {
  const llmActive = anthropicConfigured || !!apiKey;
  const [input, setInput] = useState("");
  const [turns, setTurns] = useState<Turn[]>([
    {
      role: "assistant",
      content: llmActive
        ? "ChemBrain online with LLM synthesis. I use RDKit for ADMET/similarity/substructure/scaffold/analogs, RDKit ETKDG for 3D, PubMed for literature, and SQLite for the library. Every claim is source-labelled — [RDKit], [heuristic ADMET], or [PubMed: PMID …]. I never cite a paper I wasn't handed."
        : "Direct-tools mode — no Anthropic key, so I don't do open-ended conversation, but I do route your intent to the right real tool and render its output inline (structures, 3D, ranked hits, etc.). Say 'help' for the full command list.",
    },
  ]);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [turns, loading]);

  const send = async (message: string) => {
    const text = message.trim();
    if (!text || loading) return;
    setInput("");
    setTurns((t) => [...t, { role: "user", content: text }]);
    setLoading(true);
    try {
      const history = turns.map((t) => ({ role: t.role, content: t.content }));
      const res: ChatResponse = await sendChatMessage(text, history, apiKey);
      setTurns((t) => [
        ...t,
        {
          role: "assistant",
          content: res.response,
          admet: res.admet_data ?? null,
          refs: res.literature_data ?? null,
          tool: res.tool_used ?? null,
          toolData: res.tool_data ?? null,
        },
      ]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Request failed";
      setTurns((t) => [...t, { role: "assistant", content: `Error: ${msg}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="ChemBrain"
      purpose="Ask a chemistry question or paste a SMILES. Answers cite real tools (RDKit, PubMed) with sources labelled inline; never invented citations."
      eyebrow="Assistant"
      engine={llmActive ? "Claude tool-calling · RDKit · PubMed" : "Direct tools · RDKit · PubMed (no LLM key)"}
    >
    <div className="flex flex-col h-[calc(100vh-16rem)]">
      <div ref={scrollRef} className="flex-1 overflow-y-auto thin-scroll pr-2 space-y-6">
        {turns.map((t, i) => (
          <div key={i} className="entry-in">
            <div className="eyebrow mb-1.5">
              {t.role === "user" ? "You" : t.tool ? `ChemBrain · ${t.tool}` : "ChemBrain"}
            </div>
            <div className={t.role === "user" ? "text-sm leading-relaxed text-ink" : "text-sm leading-relaxed text-ink whitespace-pre-wrap"}>
              {t.content}
            </div>
            {t.admet?.valid && <div className="mt-3"><AdmetCard data={t.admet} /></div>}
            {t.refs && t.refs.length > 0 && <div className="mt-3"><LiteratureCard references={t.refs} /></div>}
            {t.toolData && t.toolData.tool !== "admet" && t.toolData.tool !== "pubmed" && renderToolInline(t.toolData)}
          </div>
        ))}
        {loading && (
          <div>
            <div className="eyebrow mb-1.5">ChemBrain</div>
            <div className="text-sm text-ink-faint">Working…</div>
          </div>
        )}
      </div>

      <div className="pt-4 mt-4 border-t border-line">
        {turns.length <= 1 && (
          <div className="flex flex-wrap gap-1.5 mb-3">
            {STARTERS.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="text-[11px] px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted transition-colors"
              >
                {s.length > 60 ? s.slice(0, 60) + "…" : s}
              </button>
            ))}
          </div>
        )}
        <div className="flex gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(input);
              }
            }}
            placeholder="Ask a chemistry question or paste a SMILES. Enter to send · Shift+Enter for newline."
            rows={2}
            className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm placeholder-ink-faint focus:outline-none focus:border-accent transition-colors resize-none"
          />
          <button
            onClick={() => send(input)}
            disabled={loading || !input.trim()}
            className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30 self-stretch"
          >
            {loading ? "…" : "Send"}
          </button>
        </div>
      </div>
    </div>
    </Panel>
  );
};
