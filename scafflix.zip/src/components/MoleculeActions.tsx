import React from "react";
import { useActiveMolecule } from "../context/ActiveMolecule";

type Target = "admet" | "scaffold" | "similarity" | "analogs" | "mol3d" | "literature" | "substructure" | "pharmacophore" | "retro";

const LABELS: Record<Target, string> = {
  admet:         "ADMET",
  scaffold:      "Scaffold",
  similarity:    "Similar",
  analogs:       "Analogs",
  mol3d:         "3D",
  literature:    "Literature",
  substructure:  "Substructure",
  pharmacophore: "Pharmacophore",
  retro:         "Retro",
};

interface Props {
  smiles: string;
  targets?: Target[];
  compact?: boolean;
}

const DEFAULT_TARGETS: Target[] = ["admet", "scaffold", "similarity", "analogs", "mol3d"];

/**
 * Row of one-click actions. Sets the active molecule and switches modules,
 * so the user's molecule flows across the workbench without re-pasting.
 */
export const MoleculeActions: React.FC<Props> = ({ smiles, targets = DEFAULT_TARGETS, compact }) => {
  const { setSmiles, navigate } = useActiveMolecule();
  const go = (id: Target) => {
    if (smiles) setSmiles(smiles);
    navigate(id);
  };
  return (
    <div className={`flex flex-wrap gap-1 ${compact ? "" : "mt-2"}`}>
      <span className="text-[10px] uppercase tracking-wider text-ink-faint mr-1 self-center">Use in →</span>
      {targets.map((t) => (
        <button
          key={t}
          onClick={() => go(t)}
          className="text-[11px] px-2 py-0.5 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted hover:text-ink transition-colors"
        >
          {LABELS[t]}
        </button>
      ))}
    </div>
  );
};
