import React, { useState } from "react";
import { retrosynthesize, RetroResponse } from "../services/api";
import { MoleculeView } from "./MoleculeView";
import { Panel } from "./Panel";

export const RetroPanel: React.FC = () => {
  const [smiles, setSmiles] = useState("CC(=O)Nc1ccc(O)cc1");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<RetroResponse | null>(null);

  const run = async () => {
    setBusy(true);
    try {
      setResult(await retrosynthesize(smiles));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Panel
      title="Retrosynthesis"
      purpose="One-step template disconnections. Applies ten curated reverse reactions and shows the resulting starting materials for each disconnection."
      eyebrow="Design"
      engine="RDKit reverse-SMARTS · curated template set"
      wide
    >
      <div className="flex gap-2 mb-4">
        <input
          value={smiles}
          onChange={(e) => setSmiles(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !busy && run()}
          placeholder="Target SMILES"
          className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm font-mono focus:outline-none focus:border-accent"
        />
        <button onClick={run} disabled={busy || !smiles.trim()} className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong disabled:opacity-30">
          {busy ? "…" : "Disconnect"}
        </button>
      </div>

      {result && !result.valid && <div className="text-sm text-flag-risk">{result.error}</div>}

      {result?.valid && (
        <>
          <div className="flex items-start gap-4 mb-4">
            <MoleculeView smiles={result.target!} size={180} />
            <div className="text-sm">
              <div className="eyebrow mb-1">Target</div>
              <div className="font-mono text-xs text-ink-muted">{result.target}</div>
              <div className="mt-2 text-ink-muted">
                {result.count} disconnection{result.count === 1 ? "" : "s"} found across the template set.
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {(result.disconnections || []).map((d, i) => (
              <div key={i} className="border border-line rounded bg-surface p-4">
                <div className="flex items-baseline justify-between mb-3">
                  <div>
                    <div className="text-sm font-medium">{d.name}</div>
                    <div className="text-[11px] text-ink-muted">{d.description}</div>
                  </div>
                  <div className="text-[10px] tracking-wider uppercase text-ink-faint">Step {i + 1}</div>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  {d.fragments.map((frag, j) => (
                    <React.Fragment key={j}>
                      {j > 0 && <div className="text-ink-faint font-mono text-lg">+</div>}
                      <div>
                        <MoleculeView smiles={frag} size={140} />
                        <div className="mt-1 font-mono text-[10px] text-ink-faint truncate max-w-[160px]">{frag}</div>
                      </div>
                    </React.Fragment>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {result.note && (
            <div className="mt-5 pt-3 border-t border-line text-[11px] text-ink-faint italic">
              {result.note}
            </div>
          )}
        </>
      )}
    </Panel>
  );
};
