import React, { useState } from "react";
import { mathSolve, MathResponse, MathOperation } from "../services/api";
import { Panel } from "./Panel";
import { LatexText } from "./LatexText";

const OPERATIONS: { id: MathOperation; label: string; hint: string }[] = [
  { id: "solve",     label: "Solve",     hint: "Solve equation for a variable (accepts 'lhs = rhs' or 'expr' assuming = 0)" },
  { id: "diff",      label: "Diff",      hint: "Differentiate (use Order for higher derivatives)" },
  { id: "integrate", label: "Integrate", hint: "Indefinite integral, or set Lower and Upper for definite" },
  { id: "factor",    label: "Factor",    hint: "Factor a polynomial" },
  { id: "expand",    label: "Expand",    hint: "Expand a product / power" },
  { id: "simplify",  label: "Simplify",  hint: "Algebraic simplification" },
  { id: "limit",     label: "Limit",     hint: "Enter the limit point in Lower (e.g. 0, oo, -oo)" },
  { id: "series",    label: "Series",    hint: "Taylor series around the point in Lower, to Order terms" },
];

const PRESETS: { expr: string; op: MathOperation; note?: string; lower?: string; upper?: string; order?: number }[] = [
  { expr: "x^2 - 5x + 6", op: "solve",     note: "quadratic roots" },
  { expr: "x^3 - 6x^2 + 11x - 6", op: "factor", note: "cubic factoring" },
  { expr: "sin(x)*x",     op: "diff",      note: "product rule" },
  { expr: "1/(1+x^2)",    op: "integrate", note: "→ arctan" },
  { expr: "x^2",          op: "integrate", lower: "0", upper: "2", note: "definite" },
  { expr: "(1+1/n)^n",    op: "limit",     lower: "oo", note: "→ e" },
  { expr: "sin(x)",       op: "series",    lower: "0", order: 7, note: "Taylor" },
];

export const MathPanel: React.FC = () => {
  const [expression, setExpression] = useState("x^2 - 5x + 6");
  const [operation, setOperation] = useState<MathOperation>("solve");
  const [variable, setVariable] = useState("x");
  const [lower, setLower] = useState("");
  const [upper, setUpper] = useState("");
  const [order, setOrder] = useState<number>(1);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<MathResponse | null>(null);

  const run = async () => {
    setBusy(true);
    try {
      setResult(await mathSolve({ expression, operation, variable, lower, upper, order }));
    } finally {
      setBusy(false);
    }
  };

  const applyPreset = (p: typeof PRESETS[number]) => {
    setExpression(p.expr);
    setOperation(p.op);
    setLower(p.lower || "");
    setUpper(p.upper || "");
    setOrder(p.order || 1);
  };

  const showBounds = operation === "integrate" || operation === "limit" || operation === "series";
  const showOrder = operation === "diff" || operation === "series";

  return (
    <Panel
      title="Math workbench"
      purpose="Real algebra and calculus — solve, differentiate, integrate, factor, limits, Taylor series. Every result is a real SymPy computation. Works without any API key."
      eyebrow="Learn"
      engine="SymPy · KaTeX rendering"
      wide
    >
      <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-3 mb-3">
        <input
          value={expression}
          onChange={(e) => setExpression(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !busy && run()}
          placeholder="Expression (e.g. x^2 - 5x + 6, sin(x)*cos(x), 1/(1+x^2))"
          className="bg-surface border border-line rounded px-3 py-2 text-sm font-mono focus:outline-none focus:border-accent"
        />
        <div className="grid grid-cols-[1fr_auto_auto] gap-2">
          <select
            value={operation}
            onChange={(e) => setOperation(e.target.value as MathOperation)}
            className="bg-surface border border-line rounded px-3 py-2 text-sm focus:outline-none focus:border-accent"
          >
            {OPERATIONS.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
          </select>
          <input
            value={variable}
            onChange={(e) => setVariable(e.target.value)}
            className="w-14 bg-surface border border-line rounded px-2 py-2 text-sm font-mono text-center focus:outline-none focus:border-accent"
            placeholder="var"
            title="Variable (default x)"
          />
          <button
            onClick={run}
            disabled={busy || !expression.trim()}
            className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong disabled:opacity-30"
          >
            {busy ? "…" : "Compute"}
          </button>
        </div>
      </div>

      {(showBounds || showOrder) && (
        <div className="flex flex-wrap gap-2 mb-3 text-sm">
          {showBounds && (
            <>
              <input value={lower} onChange={(e) => setLower(e.target.value)} placeholder={operation === "integrate" ? "Lower bound" : operation === "limit" ? "Point (e.g. 0, oo)" : "Expand around"} className="w-40 bg-surface border border-line rounded px-3 py-1.5 font-mono focus:outline-none focus:border-accent" />
              {operation === "integrate" && (
                <input value={upper} onChange={(e) => setUpper(e.target.value)} placeholder="Upper bound" className="w-40 bg-surface border border-line rounded px-3 py-1.5 font-mono focus:outline-none focus:border-accent" />
              )}
            </>
          )}
          {showOrder && (
            <input type="number" value={order} onChange={(e) => setOrder(Math.max(1, Number(e.target.value) || 1))} placeholder="Order" className="w-24 bg-surface border border-line rounded px-3 py-1.5 font-mono focus:outline-none focus:border-accent" />
          )}
        </div>
      )}

      <div className="text-[11px] text-ink-muted mb-4">{OPERATIONS.find((o) => o.id === operation)?.hint}</div>

      <div className="eyebrow mb-2">Presets</div>
      <div className="flex flex-wrap gap-1.5 mb-5">
        {PRESETS.map((p, i) => (
          <button
            key={i}
            onClick={() => applyPreset(p)}
            className="text-[11px] px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted transition-colors"
          >
            {p.op} · {p.expr}{p.note ? ` (${p.note})` : ""}
          </button>
        ))}
      </div>

      {result && !result.valid && (
        <div className="border border-flag-risk rounded bg-flag-risk-soft/40 px-3 py-2 text-sm text-flag-risk">{result.error}</div>
      )}

      {result?.valid && (
        <div className="border border-line rounded bg-surface p-5">
          <div className="eyebrow mb-1.5">{result.operation}</div>
          <div className="text-sm mb-2">
            Input: <LatexText className="font-serif text-lg">{`$${result.input_latex}$`}</LatexText>
          </div>
          <div className="text-sm mb-4">
            Result: <LatexText className="font-serif text-xl text-accent-strong">{`$${result.output_latex}$`}</LatexText>
          </div>

          {result.steps && result.steps.length > 0 && (
            <>
              <div className="rule mb-3" />
              <div className="eyebrow mb-2">Steps</div>
              <ol className="space-y-2 text-sm">
                {result.steps.map((s, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-ink-faint font-mono text-[11px] w-6 pt-0.5">{i + 1}.</span>
                    <div className="flex-1"><LatexText>{s}</LatexText></div>
                  </li>
                ))}
              </ol>
            </>
          )}
        </div>
      )}
    </Panel>
  );
};
