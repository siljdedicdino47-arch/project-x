import React from "react";

/**
 * Shared shell for every module panel.
 *
 * Deliberately dry: an eyebrow with module + engine, a serif display title,
 * one-line purpose, a hairline rule, then the body. No decorative chrome.
 */
export const Panel: React.FC<{
  title: string;
  purpose: string;
  eyebrow?: string;
  engine?: string;
  children: React.ReactNode;
  wide?: boolean;
}> = ({ title, purpose, eyebrow, engine, children, wide }) => (
  <div className={wide ? "max-w-5xl" : "max-w-3xl"}>
    <div className="flex items-baseline justify-between mb-2">
      <div className="eyebrow">{eyebrow || "Module"}</div>
      {engine && <div className="text-[10px] font-mono text-ink-faint">{engine}</div>}
    </div>
    <h2 className="display-title mb-1.5">{title}</h2>
    <p className="text-sm text-ink-muted mb-4">{purpose}</p>
    <div className="rule mb-5" />
    {children}
  </div>
);
