import React, { useState, useRef, useEffect } from "react";
import { tutorAsk, TutorResponse, TutorMode } from "../services/api";
import { useStudySession, SUBJECTS, GRADES, Subject } from "../context/StudySession";
import { Panel } from "./Panel";
import { LatexText } from "./LatexText";

type Turn = { role: "user" | "assistant"; content: string };

interface Props {
  apiKey: string;
  anthropicConfigured: boolean;
}

const MODES: { id: TutorMode; label: string; blurb: string }[] = [
  { id: "socratic", label: "Socratic",  blurb: "I ask, you answer. Never reveals the final answer." },
  { id: "guided",   label: "Guided",    blurb: "Hints first, worked steps on request, answer only when earned." },
  { id: "direct",   label: "Direct",    blurb: "Full worked solution up front. Names the trap most students fall into." },
];

const SUBJECT_STARTERS: Record<Subject, string[]> = {
  math:      ["I'm stuck on why the derivative of x² is 2x — can you walk me through it?", "Solve x² − 5x + 6 = 0 with me", "What's the intuition behind eigenvectors? I don't get it"],
  chemistry: ["Explain SN2 vs SN1 — I keep mixing them up", "Why does hybridization matter for shape?", "Walk me through the Diels–Alder mechanism"],
  physics:   ["Derive projectile motion for me from F=ma", "What's actually the difference between voltage and current?", "Why does momentum conserve? Give me the intuition"],
  biology:   ["How does DNA replication actually work? I get stuck on the leading vs lagging strand", "Compare mitosis and meiosis — I confuse them", "Walk me through the Krebs cycle"],
  cs:        ["When should I reach for a hash map vs a tree?", "Explain recursion with the Fibonacci example", "Why is O(log n) so good?"],
  english:   ["What makes a thesis statement actually strong?", "Voice vs tone — I don't see the difference", "Help me analyze this metaphor: …"],
  history:   ["What actually caused WWI? Not just the assassination", "Compare the American and French Revolutions", "Why did the Roman Empire fall?"],
  general:   ["I have a homework problem — can you help me work through it?", "How should I study for an exam next week?", "Explain a concept I keep getting wrong"],
};

const FOLLOWUPS: { label: string; message: string }[] = [
  { label: "Explain differently",    message: "That didn't quite land. Can you explain the same idea a different way — a picture-in-words, an analogy, or a concrete numerical example?" },
  { label: "Give me a hint",         message: "I'm stuck. Give me the smallest possible hint that unblocks the next step — don't show me the whole approach." },
  { label: "Check my understanding", message: "Ask me a question to check I actually got it — not just repeat back the words." },
  { label: "Show the answer",        message: "Okay, please give me the full worked answer now, but afterwards name the mistake I would have made if I tried it myself." },
  { label: "Why is that true?",      message: "Where does that rule come from? I want the intuition, not just the recipe." },
];

export const TutorPanel: React.FC<Props> = ({ apiKey, anthropicConfigured }) => {
  const { subject, grade } = useStudySession();
  const llmActive = anthropicConfigured || !!apiKey;
  const [mode, setMode] = useState<TutorMode>("guided");
  const [input, setInput] = useState("");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setTurns([]);
    setError(null);
  }, [subject, grade]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [turns, loading]);

  const send = async (message: string) => {
    const text = message.trim();
    if (!text || loading) return;
    setInput("");
    setError(null);
    setTurns((t) => [...t, { role: "user", content: text }]);
    setLoading(true);
    try {
      const history = turns;
      const res: TutorResponse = await tutorAsk(text, subject, grade, history, mode, apiKey);
      if (!res.valid) {
        setError(res.error || "Tutor request failed");
      } else {
        setTurns((t) => [...t, { role: "assistant", content: res.response || "" }]);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Request failed");
    } finally {
      setLoading(false);
    }
  };

  const subjectLabel = SUBJECTS.find((s) => s.id === subject)?.label || subject;
  const gradeLabel = GRADES.find((g) => g.id === grade)?.label || grade;
  const modeInfo = MODES.find((m) => m.id === mode)!;

  return (
    <Panel
      title="Personal AI tutor"
      purpose={`Ask a ${subjectLabel.toLowerCase()} question. I'll answer at the ${gradeLabel} level. I don't just hand out answers — I ask what you think, diagnose why you're stuck, and only give the full solution when it's actually helping you learn.`}
      eyebrow="Learn"
      engine={llmActive ? `Claude · ${subjectLabel} · ${gradeLabel} · ${modeInfo.label}` : "Needs LLM key for open-ended tutoring"}
    >
      {!llmActive && (
        <div className="border border-flag-warn rounded bg-flag-warn-soft/40 px-4 py-3 text-sm mb-5">
          The tutor chat needs an Anthropic API key for open-ended answers. Paste one in the header (session-only).
          You can still use <span className="font-mono">Math</span> (SymPy) and every <span className="font-mono">Chemistry Lab</span> tool without a key.
        </div>
      )}

      {/* Learning mode selector — this is the philosophy made a knob. */}
      <div className="border border-line rounded bg-surface-inset p-3 mb-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-1">
            <span className="eyebrow mr-2">Learning mode</span>
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                disabled={!llmActive}
                className={`text-xs px-2.5 py-1 rounded border transition-colors disabled:opacity-40 ${
                  mode === m.id
                    ? "border-accent bg-accent-soft text-accent-strong"
                    : "border-line text-ink-muted hover:border-accent hover:text-ink"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
          <div className="text-[11px] text-ink-muted">{modeInfo.blurb}</div>
        </div>
      </div>

      <div className="flex flex-col h-[calc(100vh-22rem)]">
        <div ref={scrollRef} className="flex-1 overflow-y-auto thin-scroll pr-2 space-y-5">
          {turns.length === 0 && (
            <div>
              <div className="eyebrow mb-2">Try one of these</div>
              <div className="flex flex-wrap gap-1.5">
                {SUBJECT_STARTERS[subject].map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    disabled={!llmActive}
                    className="text-[11px] px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted transition-colors disabled:opacity-40"
                  >
                    {s.length > 70 ? s.slice(0, 70) + "…" : s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {turns.map((t, i) => {
            const isLastAssistant = t.role === "assistant" && i === turns.length - 1 && !loading;
            return (
              <div key={i} className="entry-in">
                <div className="eyebrow mb-1.5">{t.role === "user" ? "You" : "Tutor"}</div>
                <div className="text-sm leading-relaxed text-ink whitespace-pre-wrap">
                  <LatexText>{t.content}</LatexText>
                </div>
                {isLastAssistant && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {FOLLOWUPS.map((f) => (
                      <button
                        key={f.label}
                        onClick={() => send(f.message)}
                        className="text-[11px] px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted hover:text-ink transition-colors"
                        title={f.message}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}

          {loading && (
            <div>
              <div className="eyebrow mb-1.5">Tutor</div>
              <div className="text-sm text-ink-faint">Thinking…</div>
            </div>
          )}

          {error && (
            <div className="text-sm text-flag-risk border border-flag-risk rounded px-3 py-2">{error}</div>
          )}
        </div>

        <div className="pt-4 mt-4 border-t border-line">
          <div className="flex gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && llmActive) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder={`Ask your ${subjectLabel.toLowerCase()} tutor · Enter to send · Shift+Enter for newline`}
              rows={2}
              className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm placeholder-ink-faint focus:outline-none focus:border-accent transition-colors resize-none"
            />
            <button
              onClick={() => send(input)}
              disabled={loading || !input.trim() || !llmActive}
              className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30 self-stretch"
            >
              {loading ? "…" : "Ask"}
            </button>
          </div>
          <div className="mt-2 text-[10px] text-ink-faint text-right">
            Guided mode: I hint before I answer. If you want the answer now, use the "Show the answer" chip or switch to Direct.
          </div>
        </div>
      </div>
    </Panel>
  );
};
