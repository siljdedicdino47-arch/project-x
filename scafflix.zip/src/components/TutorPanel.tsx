import React, { useState, useRef, useEffect } from "react";
import { tutorAsk, TutorResponse } from "../services/api";
import { useStudySession, SUBJECTS, GRADES, Subject, Grade } from "../context/StudySession";
import { Panel } from "./Panel";
import { LatexText } from "./LatexText";

type Turn = { role: "user" | "assistant"; content: string };

interface Props {
  apiKey: string;
  anthropicConfigured: boolean;
}

const SUBJECT_STARTERS: Record<Subject, string[]> = {
  math:      ["Explain how derivatives work with an example", "Solve x² − 5x + 6 = 0 and show every step", "What's the intuition behind eigenvectors?"],
  chemistry: ["Explain SN2 vs SN1 mechanisms", "How does hybridization work? Show sp3 vs sp2", "What is the mechanism of the Diels–Alder reaction?"],
  physics:   ["Derive projectile motion from F=ma", "What is the difference between voltage and current?", "Explain conservation of momentum with an example"],
  biology:   ["How does DNA replication work?", "Compare mitosis and meiosis", "Explain the Krebs cycle step by step"],
  cs:        ["When would I use a hash map vs a binary tree?", "Explain recursion with the Fibonacci example", "What's Big-O notation and why does it matter?"],
  english:   ["What makes a thesis statement strong?", "Explain the difference between voice and tone", "Analyze the metaphor in the first stanza of…"],
  history:   ["What caused World War I?", "Compare the American and French Revolutions", "Why did the Roman Empire fall?"],
  general:   ["I have a homework question — can you help me work through it?", "How should I study for an exam next week?", "Explain a concept I'm struggling with"],
};

export const TutorPanel: React.FC<Props> = ({ apiKey, anthropicConfigured }) => {
  const { subject, grade } = useStudySession();
  const llmActive = anthropicConfigured || !!apiKey;
  const [input, setInput] = useState("");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // Reset the conversation when the student changes subject/grade — different tutor persona.
    setTurns([]);
    setError(null);
  }, [subject, grade]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [turns, loading]);

  const send = async (message: string) => {
    const text = message.trim();
    if (!text || loading) return;
    setInput("");
    setError(null);
    setTurns((t) => [...t, { role: "user", content: text }]);
    setLoading(true);
    try {
      const history = turns;
      const res: TutorResponse = await tutorAsk(text, subject, grade, history, apiKey);
      if (!res.valid) {
        setError(res.error || "Tutor request failed");
        // Roll back the just-added user turn so the input remains actionable.
      } else {
        setTurns((t) => [...t, { role: "assistant", content: res.response || "" }]);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Request failed");
    } finally {
      setLoading(false);
    }
  };

  const subjectLabel = SUBJECTS.find((s) => s.id === subject)?.label || subject;
  const gradeLabel = GRADES.find((g) => g.id === grade)?.label || grade;

  return (
    <Panel
      title="Personal AI tutor"
      purpose={`Ask a ${subjectLabel.toLowerCase()} question. I'll answer at the ${gradeLabel} level, show my work, and never invent citations. Change subject or grade any time from the header.`}
      eyebrow="Learn"
      engine={llmActive ? `Claude · ${subjectLabel} · ${gradeLabel}` : "Needs LLM key for open-ended tutoring"}
    >
      {!llmActive && (
        <div className="border border-flag-warn rounded bg-flag-warn-soft/40 px-4 py-3 text-sm mb-5">
          The tutor chat needs an Anthropic API key for open-ended answers. Paste one in the header (session-only).
          You can still use <span className="font-mono">Math</span> (SymPy) and every <span className="font-mono">Chemistry Lab</span> tool without a key.
        </div>
      )}

      <div className="flex flex-col h-[calc(100vh-18rem)]">
        <div ref={scrollRef} className="flex-1 overflow-y-auto thin-scroll pr-2 space-y-5">
          {turns.length === 0 && (
            <div>
              <div className="eyebrow mb-2">Try one of these</div>
              <div className="flex flex-wrap gap-1.5">
                {SUBJECT_STARTERS[subject].map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    disabled={!llmActive}
                    className="text-[11px] px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted transition-colors disabled:opacity-40"
                  >
                    {s.length > 70 ? s.slice(0, 70) + "…" : s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {turns.map((t, i) => (
            <div key={i} className="entry-in">
              <div className="eyebrow mb-1.5">{t.role === "user" ? "You" : "Tutor"}</div>
              <div className="text-sm leading-relaxed text-ink whitespace-pre-wrap">
                <LatexText>{t.content}</LatexText>
              </div>
            </div>
          ))}

          {loading && (
            <div>
              <div className="eyebrow mb-1.5">Tutor</div>
              <div className="text-sm text-ink-faint">Thinking…</div>
            </div>
          )}

          {error && (
            <div className="text-sm text-flag-risk border border-flag-risk rounded px-3 py-2">{error}</div>
          )}
        </div>

        <div className="pt-4 mt-4 border-t border-line">
          <div className="flex gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && llmActive) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder={`Ask your ${subjectLabel.toLowerCase()} tutor · Enter to send · Shift+Enter for newline`}
              rows={2}
              className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm placeholder-ink-faint focus:outline-none focus:border-accent transition-colors resize-none"
            />
            <button
              onClick={() => send(input)}
              disabled={loading || !input.trim() || !llmActive}
              className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30 self-stretch"
            >
              {loading ? "…" : "Ask"}
            </button>
          </div>
        </div>
      </div>
    </Panel>
  );
};
