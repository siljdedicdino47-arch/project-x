import React, { useEffect, useRef, useState } from "react";
import { generate3D, Mol3DResponse } from "../services/api";

interface Props {
  smiles: string;
  height?: number;
  style?: "stick" | "sphere" | "cartoon" | "line";
}

/** Real 3D structure viewer via RDKit (embed + MMFF) + 3Dmol.js. */
export const Mol3DView: React.FC<Props> = ({ smiles, height = 320, style = "stick" }) => {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const viewerRef = useRef<{ clear?: () => void; removeAllModels?: () => void } | null>(null);
  const [meta, setMeta] = useState<Mol3DResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setError(null);
    setMeta(null);
    setLoading(true);

    (async () => {
      try {
        const res = await generate3D(smiles);
        if (cancelled) return;
        if (!res.valid || !res.molblock) {
          setError(res.error || "Could not generate 3D structure.");
          setLoading(false);
          return;
        }
        setMeta(res);
        const $3Dmol = await import("3dmol");
        if (cancelled || !hostRef.current) return;
        // Fully clear any previous canvas; 3Dmol does not clean up after itself.
        hostRef.current.innerHTML = "";
        const viewer = $3Dmol.createViewer(hostRef.current, {
          backgroundColor: "#FBFBF7",
        });
        viewerRef.current = viewer as unknown as typeof viewerRef.current;
        viewer.addModel(res.molblock, "mol");
        if (style === "sphere") viewer.setStyle({}, { sphere: { scale: 0.35 } });
        else if (style === "line") viewer.setStyle({}, { line: { linewidth: 2 } });
        else viewer.setStyle({}, { stick: { radius: 0.15 }, sphere: { scale: 0.22 } });
        viewer.zoomTo();
        viewer.render();
        setLoading(false);
      } catch (e: unknown) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : "3D render failed");
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
      // Detach 3Dmol's canvas ourselves so React never tries to reconcile it.
      if (hostRef.current) {
        try {
          hostRef.current.innerHTML = "";
        } catch {
          // ignore
        }
      }
      viewerRef.current = null;
    };
  }, [smiles, style]);

  return (
    <div className="w-full">
      <div
        className="w-full border border-line rounded bg-surface relative overflow-hidden"
        style={{ height }}
      >
        {/* 3Dmol.js owns this node's children — React never renders inside it. */}
        <div ref={hostRef} className="absolute inset-0" />
        {loading && !error && (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-ink-faint pointer-events-none">
            Embedding conformer…
          </div>
        )}
        {error && (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-flag-risk px-4 text-center">
            {error}
          </div>
        )}
      </div>
      {meta && (
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-ink-faint font-mono">
          <span>{meta.num_atoms} atoms</span>
          <span>{meta.num_bonds} bonds</span>
          <span>forcefield · {meta.forcefield}</span>
          <span>ETKDGv3 embed · RDKit</span>
        </div>
      )}
    </div>
  );
};
