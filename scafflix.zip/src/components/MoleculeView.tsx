import React, { useEffect, useState } from "react";
import { depictMolecule } from "../services/api";

interface Props {
  smiles: string;
  size?: number;
}

/** Renders a 2D structure by asking the backend (RDKit) for an SVG. */
export const MoleculeView: React.FC<Props> = ({ smiles, size = 200 }) => {
  const [svg, setSvg] = useState<string | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setError(false);
    // 200ms debounce so bulk re-renders (e.g. a similarity table with 10 rows,
    // or the user typing in the SMILES box) don't spam /depict per keystroke.
    const timer = setTimeout(() => {
      depictMolecule(smiles)
        .then((r) => {
          if (cancelled) return;
          if (r.valid && r.svg) setSvg(r.svg);
          else setError(true);
        })
        .catch(() => !cancelled && setError(true));
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [smiles]);

  if (error) {
    return (
      <div className="flex items-center justify-center border border-line rounded bg-surface text-xs text-flag-risk" style={{ width: size, height: size * 0.75 }}>
        invalid structure
      </div>
    );
  }
  if (!svg) {
    return (
      <div className="flex items-center justify-center border border-line rounded bg-surface text-xs text-ink-faint" style={{ width: size, height: size * 0.75 }}>
        rendering…
      </div>
    );
  }
  return (
    <div
      className="border border-line rounded bg-surface overflow-hidden flex items-center justify-center [&_svg]:w-full [&_svg]:h-full [&_svg]:block"
      style={{ width: size, height: size * 0.75 }}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
};
