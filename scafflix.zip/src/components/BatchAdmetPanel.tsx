import React, { useState } from "react";
import { LibraryCompound, batchAdmet, BatchAdmetRow } from "../services/api";
import { Panel } from "./Panel";

interface Props {
  compounds: LibraryCompound[];
}

type SortKey = "name" | "mw" | "logp" | "tpsa" | "logS" | "hia" | "bbb" | "herg" | "lipinski_violations";

const FLAG_DOT: Record<string, string> = {
  green: "#2F7D5A",
  amber: "#A9762E",
  red: "#AE3B3B",
};

export const BatchAdmetPanel: React.FC<Props> = ({ compounds }) => {
  const [rows, setRows] = useState<BatchAdmetRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const run = async () => {
    setLoading(true);
    try {
      const res = await batchAdmet(compounds);
      setRows(res.rows);
    } finally {
      setLoading(false);
    }
  };

  const sorted = [...rows].sort((a, b) => {
    const av = (a as unknown as Record<string, unknown>)[sortKey];
    const bv = (b as unknown as Record<string, unknown>)[sortKey];
    if (av === undefined || bv === undefined) return 0;
    if (typeof av === "number" && typeof bv === "number") {
      return sortDir === "asc" ? av - bv : bv - av;
    }
    const as = String(av);
    const bs = String(bv);
    return sortDir === "asc" ? as.localeCompare(bs) : bs.localeCompare(as);
  });

  const toggle = (k: SortKey) => {
    if (sortKey === k) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else {
      setSortKey(k);
      setSortDir("asc");
    }
  };

  const Th: React.FC<{ k: SortKey; label: string; right?: boolean }> = ({ k, label, right }) => (
    <th
      onClick={() => toggle(k)}
      className={`px-3 py-2 eyebrow font-medium cursor-pointer select-none hover:text-ink transition-colors ${
        right ? "text-right" : "text-left"
      }`}
    >
      {label}
      {sortKey === k && <span className="ml-1 text-ink-faint">{sortDir === "asc" ? "↑" : "↓"}</span>}
    </th>
  );

  return (
    <Panel
      title="Batch ADMET"
      purpose="Compute Lipinski + ADMET flags across the entire compound library. Click a column header to sort."
      eyebrow="Analyze"
      engine="RDKit · Descriptors · ESOL"
      wide
    >
      <div className="flex items-center justify-between mb-5">
        <div className="text-sm text-ink-muted">
          Runs RDKit ADMET across all {compounds.length} library compounds.
        </div>
        <button
          onClick={run}
          disabled={loading || compounds.length === 0}
          className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30"
        >
          {loading ? "Running…" : "Run batch"}
        </button>
      </div>

      {rows.length > 0 && (
        <div className="border border-line rounded bg-surface overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-surface-inset border-b border-line">
              <tr>
                <Th k="name" label="Compound" />
                <Th k="mw" label="MW" right />
                <Th k="logp" label="LogP" right />
                <Th k="tpsa" label="TPSA" right />
                <Th k="logS" label="logS" right />
                <Th k="hia" label="HIA %" right />
                <Th k="bbb" label="BBB" right />
                <Th k="herg" label="hERG" right />
                <Th k="lipinski_violations" label="Lip. viol." right />
              </tr>
            </thead>
            <tbody>
              {sorted.map((r, i) => (
                <tr key={i} className="border-b border-line last:border-b-0">
                  <td className="px-3 py-2">
                    <div>{r.name}</div>
                    <div className="text-[10px] font-mono text-ink-faint truncate max-w-[220px]">
                      {r.smiles}
                    </div>
                  </td>
                  {!r.valid ? (
                    <td colSpan={8} className="px-3 py-2 text-xs text-flag-risk">
                      {r.error}
                    </td>
                  ) : (
                    <>
                      <td className="px-3 py-2 text-right metric">{r.mw?.toFixed(1)}</td>
                      <FlagCell value={r.logp?.toFixed(2)} flag={r.logP_flag} />
                      <td className="px-3 py-2 text-right metric">{r.tpsa?.toFixed(1)}</td>
                      <FlagCell value={r.logS?.toFixed(2)} flag={r.logS_flag} />
                      <FlagCell value={r.hia?.toFixed(0)} flag={r.hia_flag} />
                      <FlagCell value={r.bbb?.toFixed(2)} flag={r.bbb_flag} />
                      <FlagCell value={r.herg?.toFixed(2)} flag={r.herg_flag} />
                      <td className="px-3 py-2 text-right metric">
                        <span className={r.lipinski_pass ? "text-flag-good" : "text-flag-warn"}>
                          {r.lipinski_violations}
                        </span>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {rows.length === 0 && !loading && (
        <div className="border border-dashed border-line rounded p-8 text-center text-sm text-ink-faint">
          Click <span className="text-ink">Run batch</span> to compute properties across the library.
        </div>
      )}
    </Panel>
  );
};

const FlagCell: React.FC<{ value?: string; flag?: string }> = ({ value, flag }) => (
  <td className="px-3 py-2 text-right">
    <span className="metric mr-2">{value ?? "—"}</span>
    {flag && (
      <span
        className="inline-block w-1.5 h-1.5 rounded-full align-middle"
        style={{ backgroundColor: FLAG_DOT[flag] || FLAG_DOT.amber }}
      />
    )}
  </td>
);
