import React, { useMemo } from "react";
import katex from "katex";

/**
 * Renders a mixed-content string with inline ($...$) and block ($$...$$) LaTeX
 * segments. Non-LaTeX text is passed through verbatim. Safe by default — KaTeX
 * renders with throwOnError:false so a mistyped equation shows as text.
 */
export const LatexText: React.FC<{ children: string; className?: string }> = ({ children, className }) => {
  const parts = useMemo(() => tokenize(children), [children]);
  return (
    <span className={className}>
      {parts.map((p, i) =>
        p.kind === "text" ? (
          <React.Fragment key={i}>{p.value}</React.Fragment>
        ) : (
          <span
            key={i}
            className={p.kind === "block" ? "block my-2 overflow-x-auto" : "inline-block align-middle"}
            dangerouslySetInnerHTML={{
              __html: katex.renderToString(p.value, {
                throwOnError: false,
                displayMode: p.kind === "block",
                output: "html",
              }),
            }}
          />
        ),
      )}
    </span>
  );
};

type Part = { kind: "text" | "inline" | "block"; value: string };

function tokenize(src: string): Part[] {
  const parts: Part[] = [];
  let i = 0;
  const push = (kind: Part["kind"], value: string) => {
    if (value.length > 0) parts.push({ kind, value });
  };
  while (i < src.length) {
    if (src[i] === "$" && src[i + 1] === "$") {
      const end = src.indexOf("$$", i + 2);
      if (end === -1) {
        push("text", src.slice(i));
        return parts;
      }
      push("block", src.slice(i + 2, end));
      i = end + 2;
      continue;
    }
    if (src[i] === "$") {
      const end = src.indexOf("$", i + 1);
      if (end === -1) {
        push("text", src.slice(i));
        return parts;
      }
      push("inline", src.slice(i + 1, end));
      i = end + 1;
      continue;
    }
    // Consume plain text until the next $ (or end).
    const next = src.indexOf("$", i);
    if (next === -1) {
      push("text", src.slice(i));
      return parts;
    }
    push("text", src.slice(i, next));
    i = next;
  }
  return parts;
}
