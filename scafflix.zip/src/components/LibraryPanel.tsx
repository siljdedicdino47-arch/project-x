import React, { useState } from "react";
import { LibraryCompound, addLibraryCompound, deleteLibraryCompound } from "../services/api";
import { MoleculeView } from "./MoleculeView";
import { Panel } from "./Panel";
import { MoleculeActions } from "./MoleculeActions";

interface Props {
  compounds: LibraryCompound[];
  onChange: () => void;
}

export const LibraryPanel: React.FC<Props> = ({ compounds, onChange }) => {
  const [name, setName] = useState("");
  const [smiles, setSmiles] = useState("");
  const [tag, setTag] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const add = async () => {
    if (!smiles.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      await addLibraryCompound(name || "Unnamed", smiles, tag);
      setName("");
      setSmiles("");
      setTag("");
      onChange();
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed to add");
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: number) => {
    try {
      await deleteLibraryCompound(id);
      onChange();
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed to delete");
    }
  };

  return (
    <Panel
      title="Compound library"
      purpose="Persistent SQLite-backed store. Every SMILES is validated by RDKit before it lands here; downstream tools read from this list."
      eyebrow="Library"
      engine="SQLite · RDKit canonicalization"
      wide
    >
      <div className="border border-line rounded bg-surface p-4 mb-5">
        <div className="eyebrow mb-3">Add a compound</div>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_2fr_1fr_auto] gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            className="bg-surface-inset border border-line rounded px-3 py-2 text-sm focus:outline-none focus:border-accent"
          />
          <input
            value={smiles}
            onChange={(e) => setSmiles(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !busy && add()}
            placeholder="SMILES (required, validated by RDKit)"
            className="bg-surface-inset border border-line rounded px-3 py-2 text-sm font-mono focus:outline-none focus:border-accent"
          />
          <input
            value={tag}
            onChange={(e) => setTag(e.target.value)}
            placeholder="Tag (optional)"
            className="bg-surface-inset border border-line rounded px-3 py-2 text-sm focus:outline-none focus:border-accent"
          />
          <button
            onClick={add}
            disabled={busy || !smiles.trim()}
            className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30"
          >
            {busy ? "…" : "Add"}
          </button>
        </div>
        {err && <div className="mt-2 text-xs text-flag-risk">{err}</div>}
      </div>

      <div className="eyebrow mb-2">
        Persisted library · {compounds.length} compound{compounds.length === 1 ? "" : "s"}
      </div>
      <div className="border border-line rounded bg-surface overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-surface-inset border-b border-line">
            <tr className="text-left">
              <th className="px-3 py-2 font-medium eyebrow">Structure</th>
              <th className="px-3 py-2 font-medium eyebrow">Name · tag</th>
              <th className="px-3 py-2 font-medium eyebrow">Canonical SMILES</th>
              <th className="px-3 py-2 font-medium eyebrow"></th>
            </tr>
          </thead>
          <tbody>
            {compounds.length === 0 && (
              <tr>
                <td colSpan={4} className="px-3 py-6 text-center text-ink-faint text-sm">
                  Library empty. Add a compound above.
                </td>
              </tr>
            )}
            {compounds.map((c) => (
              <tr key={c.id} className="border-b border-line last:border-b-0">
                <td className="px-3 py-3 w-[112px]">
                  <MoleculeView smiles={c.smiles} size={96} />
                </td>
                <td className="px-3 py-3 align-top">
                  <div className="font-medium">{c.name}</div>
                  {c.tag && <div className="text-[11px] text-ink-muted mt-0.5">{c.tag}</div>}
                </td>
                <td className="px-3 py-3 align-top">
                  <div className="text-xs font-mono text-ink-muted break-all">
                    {c.canonical_smiles}
                  </div>
                  <div className="mt-1.5">
                    <MoleculeActions smiles={c.smiles} compact />
                  </div>
                </td>
                <td className="px-3 py-3 align-top text-right">
                  <button
                    onClick={() => remove(c.id)}
                    className="text-[11px] text-ink-muted hover:text-flag-risk transition-colors"
                  >
                    remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );
};
