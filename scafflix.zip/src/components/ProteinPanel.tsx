import React, { useEffect, useRef, useState } from "react";
import { fetchProtein, ProteinResponse } from "../services/api";
import { Panel } from "./Panel";

type Style = "cartoon" | "surface" | "stick";

const PRESETS: { id: string; label: string }[] = [
  { id: "1ATP", label: "1ATP · PKA + ATP" },
  { id: "2HYY", label: "2HYY · Abl + imatinib" },
  { id: "1HSG", label: "1HSG · HIV protease" },
  { id: "4HHB", label: "4HHB · hemoglobin" },
  { id: "1AKI", label: "1AKI · lysozyme" },
];

export const ProteinPanel: React.FC = () => {
  const [pdbId, setPdbId] = useState("1ATP");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [meta, setMeta] = useState<ProteinResponse | null>(null);
  const [style, setStyle] = useState<Style>("cartoon");
  const [showLigand, setShowLigand] = useState(true);
  const hostRef = useRef<HTMLDivElement | null>(null);

  const load = async (id: string) => {
    setBusy(true);
    setError(null);
    setMeta(null);
    try {
      const r = await fetchProtein(id);
      if (!r.valid) {
        setError(r.error || "Failed to fetch structure.");
        setBusy(false);
        return;
      }
      setMeta(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Fetch failed");
    } finally {
      setBusy(false);
    }
  };

  // Load once on mount so users see something immediately.
  useEffect(() => {
    load(pdbId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Render/re-render 3Dmol whenever data or style changes.
  useEffect(() => {
    if (!meta?.pdb || !hostRef.current) return;
    let cancelled = false;
    (async () => {
      const $3Dmol = await import("3dmol");
      if (cancelled || !hostRef.current) return;
      hostRef.current.innerHTML = "";
      const viewer = $3Dmol.createViewer(hostRef.current, { backgroundColor: "#FBFBF7" });
      viewer.addModel(meta.pdb!, "pdb");

      // Protein backbone
      if (style === "cartoon") {
        viewer.setStyle({ hetflag: false }, { cartoon: { color: "spectrum" } });
      } else if (style === "surface") {
        viewer.setStyle({ hetflag: false }, { cartoon: { color: "spectrum", opacity: 0.6 } });
        viewer.addSurface($3Dmol.SurfaceType.VDW, { opacity: 0.55, color: "#8AA39A" }, { hetflag: false });
      } else {
        viewer.setStyle({ hetflag: false }, { stick: { radius: 0.12 } });
      }

      // Ligand (non-water HET atoms)
      if (showLigand) {
        viewer.setStyle({ hetflag: true, not: { resn: "HOH" } }, {
          stick: { radius: 0.2, colorscheme: "greenCarbon" },
          sphere: { scale: 0.28 },
        });
      }

      viewer.zoomTo();
      viewer.render();
    })();
    return () => {
      cancelled = true;
      if (hostRef.current) hostRef.current.innerHTML = "";
    };
  }, [meta, style, showLigand]);

  return (
    <Panel
      title="Protein viewer"
      purpose="Load a real experimental structure from the RCSB PDB and view it in cartoon, surface, or stick styles. Ligands and cofactors highlighted."
      eyebrow="Structural biology"
      engine="RCSB PDB · 3Dmol.js"
      wide
    >
      <div className="flex gap-2 mb-3">
        <input
          value={pdbId}
          onChange={(e) => setPdbId(e.target.value.toUpperCase())}
          onKeyDown={(e) => e.key === "Enter" && !busy && load(pdbId)}
          placeholder="PDB ID (e.g. 1ATP)"
          maxLength={4}
          className="w-32 bg-surface border border-line rounded px-3 py-2 text-sm font-mono uppercase focus:outline-none focus:border-accent"
        />
        <button
          onClick={() => load(pdbId)}
          disabled={busy || pdbId.length !== 4}
          className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong disabled:opacity-30"
        >
          {busy ? "Fetching…" : "Load"}
        </button>
        <div className="flex-1" />
        <div className="flex items-center gap-1">
          {(["cartoon", "surface", "stick"] as Style[]).map((s) => (
            <button
              key={s}
              onClick={() => setStyle(s)}
              className={`text-xs px-2.5 py-1.5 rounded border ${style === s ? "border-accent bg-accent-soft text-ink" : "border-line text-ink-muted hover:border-accent"}`}
            >
              {s}
            </button>
          ))}
          <label className="ml-3 text-xs text-ink-muted flex items-center gap-1.5">
            <input type="checkbox" checked={showLigand} onChange={(e) => setShowLigand(e.target.checked)} className="accent-accent" />
            ligand
          </label>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-4">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            onClick={() => { setPdbId(p.id); load(p.id); }}
            className="text-xs px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft transition-colors"
          >
            {p.label}
          </button>
        ))}
      </div>

      {error && <div className="text-sm text-flag-risk mb-3">{error}</div>}

      <div className="border border-line rounded bg-surface relative overflow-hidden" style={{ height: 480 }}>
        <div ref={hostRef} className="absolute inset-0" />
        {busy && (
          <div className="absolute inset-0 flex items-center justify-center text-xs text-ink-faint pointer-events-none">
            Fetching {pdbId} from RCSB…
          </div>
        )}
      </div>

      {meta?.valid && (
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="eyebrow mb-1.5">Header</div>
            <div className="text-sm leading-relaxed">{meta.title}</div>
            <div className="text-[11px] font-mono text-ink-faint mt-1">
              {meta.pdb_id} · {meta.num_atoms} atoms{meta.resolution_A ? ` · ${meta.resolution_A} Å` : ""}
            </div>
          </div>
          <div>
            <div className="eyebrow mb-1.5">Chains · ligands</div>
            <div className="text-sm">
              <div><span className="text-ink-faint">chains:</span> {meta.chains?.join(", ") || "—"}</div>
              <div><span className="text-ink-faint">ligands:</span>{" "}
                {meta.ligands && meta.ligands.length > 0 ? meta.ligands.map((l) => (
                  <span key={l} className="inline-block font-mono text-[11px] mr-1.5 px-1.5 py-0.5 border border-line rounded">{l}</span>
                )) : <span className="text-ink-faint">none</span>}
              </div>
            </div>
          </div>
        </div>
      )}
    </Panel>
  );
};
