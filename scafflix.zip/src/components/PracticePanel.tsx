import React, { useState } from "react";
import { practiceGenerate, practiceCheck, PracticeResponse, PracticeProblem } from "../services/api";
import { useStudySession, SUBJECTS, GRADES } from "../context/StudySession";
import { Panel } from "./Panel";
import { LatexText } from "./LatexText";

interface Props {
  apiKey: string;
  anthropicConfigured: boolean;
}

type Feedback = { correct: boolean; note: string };

export const PracticePanel: React.FC<Props> = ({ apiKey, anthropicConfigured }) => {
  const { subject, grade } = useStudySession();
  const llmActive = anthropicConfigured || !!apiKey;
  const [topic, setTopic] = useState("");
  const [count, setCount] = useState(3);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<PracticeResponse | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [feedback, setFeedback] = useState<Record<number, Feedback>>({});
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});

  const subjectLabel = SUBJECTS.find((s) => s.id === subject)?.label || subject;
  const gradeLabel = GRADES.find((g) => g.id === grade)?.label || grade;

  const generate = async () => {
    if (!topic.trim()) return;
    setBusy(true);
    setAnswers({});
    setFeedback({});
    setRevealed({});
    try {
      setResult(await practiceGenerate(subject, grade, topic.trim(), count, apiKey));
    } finally {
      setBusy(false);
    }
  };

  const check = async (p: PracticeProblem) => {
    const student = answers[p.index] || "";
    const r = await practiceCheck(student, p.answer);
    setFeedback((f) => ({ ...f, [p.index]: r }));
  };

  return (
    <Panel
      title="Practice problems"
      purpose={`Generate ${subjectLabel.toLowerCase()} problems at the ${gradeLabel} level, work them yourself, and get graded feedback with worked solutions.`}
      eyebrow="Learn"
      engine="Claude problem generator · string-and-numeric answer check"
      wide
    >
      {!llmActive && (
        <div className="border border-flag-warn rounded bg-flag-warn-soft/40 px-4 py-3 text-sm mb-5">
          Practice generation needs an Anthropic API key (session-only entry in the header). For deterministic math practice without a key, use the Math workbench instead.
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_auto] gap-2 mb-5">
        <input
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !busy && llmActive && generate()}
          placeholder={`Topic (e.g. "${subject === "math" ? "quadratic equations" : subject === "chemistry" ? "SN2 reactions" : "cell division"}")`}
          className="bg-surface border border-line rounded px-3 py-2 text-sm focus:outline-none focus:border-accent"
        />
        <input
          type="number"
          min={1}
          max={8}
          value={count}
          onChange={(e) => setCount(Math.min(8, Math.max(1, Number(e.target.value) || 3)))}
          className="w-20 bg-surface border border-line rounded px-3 py-2 text-sm text-center font-mono focus:outline-none focus:border-accent"
          title="How many problems (1–8)"
        />
        <button
          onClick={generate}
          disabled={busy || !topic.trim() || !llmActive}
          className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong disabled:opacity-30"
        >
          {busy ? "Generating…" : "Generate"}
        </button>
      </div>

      {result && !result.valid && (
        <div className="border border-flag-risk rounded bg-flag-risk-soft/40 px-3 py-2 text-sm text-flag-risk">{result.error}</div>
      )}

      {result?.valid && result.problems && (
        <div className="space-y-4">
          <div className="text-xs text-ink-muted">
            {result.problems.length} problems on <span className="text-ink">{result.topic}</span> · {subjectLabel} · {gradeLabel}
          </div>
          {result.problems.map((p) => {
            const fb = feedback[p.index];
            const isRevealed = !!revealed[p.index];
            return (
              <div key={p.index} className="border border-line rounded bg-surface p-4">
                <div className="flex items-baseline gap-3 mb-2">
                  <div className="font-serif text-xl leading-none text-accent-strong">{p.index}</div>
                  <div className="text-sm leading-relaxed flex-1"><LatexText>{p.question}</LatexText></div>
                </div>

                <div className="mt-3 flex gap-2 items-stretch">
                  <input
                    value={answers[p.index] || ""}
                    onChange={(e) => setAnswers((a) => ({ ...a, [p.index]: e.target.value }))}
                    onKeyDown={(e) => e.key === "Enter" && check(p)}
                    placeholder="Your answer"
                    className="flex-1 bg-surface-inset border border-line rounded px-3 py-1.5 text-sm font-mono focus:outline-none focus:border-accent"
                  />
                  <button onClick={() => check(p)} className="px-3 py-1.5 border border-line rounded text-sm hover:border-accent">Check</button>
                  <button onClick={() => setRevealed((r) => ({ ...r, [p.index]: !r[p.index] }))} className="px-3 py-1.5 border border-line rounded text-sm hover:border-accent">
                    {isRevealed ? "Hide solution" : "Show solution"}
                  </button>
                </div>

                {fb && (
                  <div className={`mt-2 text-sm ${fb.correct ? "text-flag-good" : "text-flag-warn"}`}>
                    {fb.correct ? "Correct ✓" : "Not quite — try again or reveal the solution."} <span className="text-ink-faint text-[11px]">· {fb.note}</span>
                  </div>
                )}

                {p.hint && !isRevealed && (
                  <div className="mt-3 text-[11px] text-ink-muted">
                    <span className="eyebrow mr-2">Hint</span><LatexText>{p.hint}</LatexText>
                  </div>
                )}

                {isRevealed && (
                  <div className="mt-3 pt-3 border-t border-line-soft">
                    <div className="eyebrow mb-1.5">Solution</div>
                    <div className="text-sm leading-relaxed"><LatexText>{p.solution}</LatexText></div>
                    <div className="mt-2 text-[11px] text-ink-faint">
                      Canonical answer: <span className="font-mono text-ink">{p.answer}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Panel>
  );
};
