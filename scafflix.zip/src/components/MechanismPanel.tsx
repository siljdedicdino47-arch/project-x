import React, { useState } from "react";
import { studyMechanism, MechanismResponse, MechanismSideMol } from "../services/api";
import { Panel } from "./Panel";

interface Props {
  apiKey: string;
  anthropicConfigured: boolean;
}

const STARTERS = [
  "Explain the mechanism of the Diels–Alder reaction between cyclopentadiene and maleic anhydride",
  "Show the SN2 mechanism of 1-bromobutane + hydroxide",
  "Draw the acid-catalyzed hydration of 2-methylpropene (Markovnikov)",
  "E1 dehydration of tert-butanol with H2SO4",
  "Mechanism of the aldol condensation between two acetaldehyde molecules",
  "Fischer esterification of acetic acid and ethanol",
];

const SideMol: React.FC<{ mol: MechanismSideMol }> = ({ mol }) => {
  if (!mol.valid) {
    return (
      <div className="border border-flag-risk rounded bg-surface p-2 text-[10px] text-flag-risk max-w-[180px]">
        <div className="font-mono truncate">{mol.smiles_input}</div>
        <div>LLM produced an invalid SMILES here.</div>
      </div>
    );
  }
  return (
    <div className="w-[160px]">
      <div
        className="w-full h-[120px] border border-line rounded bg-surface overflow-hidden [&_svg]:w-full [&_svg]:h-full [&_svg]:block"
        dangerouslySetInnerHTML={{ __html: mol.svg || "" }}
      />
      <div className="mt-1 text-[10px] font-mono text-ink-faint truncate">{mol.smiles}</div>
    </div>
  );
};

const Side: React.FC<{ mols: MechanismSideMol[]; label: string }> = ({ mols, label }) => (
  <div>
    <div className="eyebrow mb-2">{label}</div>
    <div className="flex flex-wrap gap-3 items-start">
      {mols.map((m, i) => (
        <React.Fragment key={i}>
          {i > 0 && <div className="self-center text-ink-faint font-mono text-lg leading-none">+</div>}
          <SideMol mol={m} />
        </React.Fragment>
      ))}
    </div>
  </div>
);

const StepCard: React.FC<{ step: MechanismStep }> = ({ step }) => (
  <div className="border border-line rounded bg-surface p-5">
    <div className="flex items-baseline gap-3 mb-4">
      <div className="font-serif text-2xl leading-none text-accent-strong">{step.index}</div>
      <div className="font-medium text-ink">{step.title}</div>
    </div>

    <div className="flex flex-col lg:flex-row items-start gap-4">
      <div className="flex-1"><Side mols={step.reactants} label="Reactants" /></div>
      <div className="text-ink-faint font-mono text-xl self-center px-2">⟶</div>
      <div className="flex-1"><Side mols={step.products} label="Products" /></div>
    </div>

    <div className="mt-5 pt-4 border-t border-line-soft">
      <div className="eyebrow mb-1.5">Arrow pushing</div>
      <p className="text-sm leading-relaxed">{step.arrow_pushing}</p>
      {step.notes && (
        <>
          <div className="eyebrow mt-4 mb-1.5">Notes</div>
          <p className="text-sm text-ink-muted leading-relaxed">{step.notes}</p>
        </>
      )}
    </div>
  </div>
);

type MechanismStep = MechanismResponse["steps"] extends (infer S)[] | undefined ? S : never;

export const MechanismPanel: React.FC<Props> = ({ apiKey, anthropicConfigured }) => {
  const [question, setQuestion] = useState(STARTERS[0]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MechanismResponse | null>(null);

  const canRun = anthropicConfigured || !!apiKey;

  const run = async (q: string) => {
    if (!q.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const r = await studyMechanism(q, apiKey);
      setResult(r);
    } catch (e: unknown) {
      setResult({ valid: false, error: e instanceof Error ? e.message : "request failed" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="Mechanism Explorer"
      purpose="Step-by-step reaction mechanisms with intermediates drawn by RDKit and arrow-pushing described per step. Written for students; verify against a textbook."
      eyebrow="Study"
      engine="Claude (structured tool call) · RDKit depict"
      wide
    >
      {!canRun && (
        <div className="border border-flag-warn rounded bg-flag-warn-soft/40 px-4 py-3 text-sm mb-5">
          The Mechanism Explorer needs an Anthropic API key. Paste one into the header field (session-only, not saved to disk), or set{" "}
          <span className="font-mono">ANTHROPIC_API_KEY</span> in <span className="font-mono">backend/.env</span> and restart uvicorn.
        </div>
      )}

      <div className="flex gap-2 mb-4">
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && canRun) {
              e.preventDefault();
              run(question);
            }
          }}
          rows={2}
          placeholder="Ask a mechanism question: 'Explain the SN2 mechanism of…' "
          className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm focus:outline-none focus:border-accent resize-none"
        />
        <button
          onClick={() => run(question)}
          disabled={loading || !canRun || !question.trim()}
          className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30 self-stretch"
        >
          {loading ? "Working…" : "Explain"}
        </button>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-6">
        {STARTERS.map((s) => (
          <button
            key={s}
            onClick={() => {
              setQuestion(s);
              if (canRun) run(s);
            }}
            className="text-[11px] px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft text-ink-muted transition-colors"
          >
            {s.length > 62 ? s.slice(0, 62) + "…" : s}
          </button>
        ))}
      </div>

      {result && !result.valid && (
        <div className="border border-flag-risk rounded bg-flag-risk-soft/40 px-4 py-3 text-sm text-flag-risk">
          {result.error}
        </div>
      )}

      {result && result.valid && (
        <div className="space-y-6">
          <div>
            <div className="eyebrow mb-1">Reaction</div>
            <h3 className="font-serif text-2xl leading-tight text-ink mb-2">{result.reaction_name}</h3>
            <p className="text-sm text-ink-muted leading-relaxed">{result.overview}</p>
            {result.smiles_validation && result.smiles_validation.valid < result.smiles_validation.total && (
              <div className="mt-3 inline-flex items-center gap-2 px-2.5 py-1 border border-flag-warn rounded text-[11px] text-flag-warn">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-flag-warn" />
                {result.smiles_validation.valid} / {result.smiles_validation.total} intermediates parsed cleanly. Unparseable steps are flagged inline.
              </div>
            )}
          </div>

          <div className="space-y-4">
            {(result.steps || []).map((s) => (
              <StepCard key={s.index} step={s} />
            ))}
          </div>

          {(result.principles?.length || result.pitfalls?.length) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {result.principles && result.principles.length > 0 && (
                <div className="border border-line rounded bg-surface p-4">
                  <div className="eyebrow mb-2">Principles</div>
                  <ul className="text-sm space-y-1">
                    {result.principles.map((p, i) => (
                      <li key={i} className="flex gap-2">
                        <span className="text-ink-faint">·</span>
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {result.pitfalls && result.pitfalls.length > 0 && (
                <div className="border border-line rounded bg-surface p-4">
                  <div className="eyebrow mb-2">Common pitfalls</div>
                  <ul className="text-sm space-y-1">
                    {result.pitfalls.map((p, i) => (
                      <li key={i} className="flex gap-2">
                        <span className="text-ink-faint">·</span>
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {result.caveat && (
            <div className="border-t border-line pt-3 text-[11px] text-ink-faint italic">
              {result.caveat}
            </div>
          )}
        </div>
      )}
    </Panel>
  );
};
