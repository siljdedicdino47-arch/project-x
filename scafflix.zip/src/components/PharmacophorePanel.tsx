import React, { useState } from "react";
import { extractPharmacophore, shapeOverlay, PharmacophoreResponse, OverlayResponse } from "../services/api";
import { MoleculeView } from "./MoleculeView";
import { Panel } from "./Panel";

const FAMILY_COLORS: Record<string, string> = {
  Donor:            "bg-flag-good-soft text-flag-good border-flag-good/40",
  Acceptor:         "bg-flag-warn-soft text-flag-warn border-flag-warn/40",
  Aromatic:         "bg-accent-soft text-accent-strong border-accent/40",
  Hydrophobe:       "bg-surface-inset text-ink-muted border-line-strong",
  LumpedHydrophobe: "bg-surface-inset text-ink-muted border-line-strong",
  NegIonizable:     "bg-flag-risk-soft text-flag-risk border-flag-risk/40",
  PosIonizable:     "bg-flag-risk-soft text-flag-risk border-flag-risk/40",
  ZnBinder:         "bg-flag-warn-soft text-flag-warn border-flag-warn/40",
};

export const PharmacophorePanel: React.FC = () => {
  const [smiles, setSmiles] = useState("CC(=O)Oc1ccccc1C(=O)O");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<PharmacophoreResponse | null>(null);

  const [refSmi, setRefSmi] = useState("CC(=O)Nc1ccc(O)cc1");
  const [qrySmi, setQrySmi] = useState("CC(=O)Oc1ccccc1C(=O)O");
  const [overlay, setOverlay] = useState<OverlayResponse | null>(null);
  const [overlayBusy, setOverlayBusy] = useState(false);

  const run = async () => {
    setBusy(true);
    try {
      setResult(await extractPharmacophore(smiles));
    } finally {
      setBusy(false);
    }
  };

  const runOverlay = async () => {
    setOverlayBusy(true);
    try {
      setOverlay(await shapeOverlay(qrySmi, refSmi));
    } finally {
      setOverlayBusy(false);
    }
  };

  return (
    <Panel
      title="Pharmacophore + shape overlay"
      purpose="Extract H-bond donors, acceptors, aromatic centers, and hydrophobes with RDKit. Overlay two molecules by 3D shape using Open3DAlign."
      eyebrow="Design"
      engine="RDKit BaseFeatures · Open3DAlign"
      wide
    >
      <div className="mb-6">
        <div className="eyebrow mb-2">Feature extraction</div>
        <div className="flex gap-2 mb-3">
          <input
            value={smiles}
            onChange={(e) => setSmiles(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !busy && run()}
            className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm font-mono focus:outline-none focus:border-accent"
            placeholder="SMILES"
          />
          <button onClick={run} disabled={busy || !smiles.trim()} className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong disabled:opacity-30">
            {busy ? "…" : "Extract"}
          </button>
        </div>

        {result?.valid && (
          <div className="flex flex-col md:flex-row gap-4 items-start">
            <MoleculeView smiles={result.smiles!} size={220} />
            <div className="flex-1">
              <div className="flex flex-wrap gap-2 mb-3">
                {Object.entries(result.counts || {}).map(([fam, n]) => (
                  <span key={fam} className={`text-xs px-2 py-1 border rounded ${FAMILY_COLORS[fam] || "border-line text-ink-muted"}`}>
                    {fam} · {n}
                  </span>
                ))}
              </div>
              <div className="border border-line rounded bg-surface divide-y divide-line text-sm max-h-64 overflow-y-auto thin-scroll">
                {result.features?.map((f, i) => (
                  <div key={i} className="px-3 py-1.5 flex items-center justify-between">
                    <span>{f.family} · {f.type}</span>
                    <span className="font-mono text-[11px] text-ink-faint">atoms {f.atom_indices.join(",")}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        {result && !result.valid && <div className="text-sm text-flag-risk">{result.error}</div>}
      </div>

      <div className="rule mb-5" />

      <div>
        <div className="eyebrow mb-2">3D shape overlay (Open3DAlign)</div>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-2 mb-3">
          <input value={qrySmi} onChange={(e) => setQrySmi(e.target.value)} placeholder="Query SMILES" className="bg-surface border border-line rounded px-3 py-2 text-sm font-mono focus:outline-none focus:border-accent" />
          <input value={refSmi} onChange={(e) => setRefSmi(e.target.value)} placeholder="Reference SMILES" className="bg-surface border border-line rounded px-3 py-2 text-sm font-mono focus:outline-none focus:border-accent" />
          <button onClick={runOverlay} disabled={overlayBusy || !qrySmi.trim() || !refSmi.trim()} className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong disabled:opacity-30">
            {overlayBusy ? "Aligning…" : "Overlay"}
          </button>
        </div>

        {overlay?.valid && (
          <div className="border border-line rounded bg-surface p-4 text-sm">
            <div className="flex gap-6 mb-3">
              <div><span className="text-ink-faint">RMSD:</span> <span className="font-mono">{overlay.rmsd_A} Å</span></div>
              <div><span className="text-ink-faint">O3A score:</span> <span className="font-mono">{overlay.o3a_score}</span></div>
            </div>
            <div className="text-xs text-ink-muted">
              MOL blocks generated for query and reference (post-alignment). Feed either into the 3D structure module to inspect the aligned geometry.
            </div>
          </div>
        )}
        {overlay && !overlay.valid && <div className="text-sm text-flag-risk">{overlay.error}</div>}
      </div>
    </Panel>
  );
};
