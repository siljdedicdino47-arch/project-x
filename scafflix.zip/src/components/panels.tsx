import React, { useState, useEffect } from "react";
import {
  Compound,
  predictAdmetDirect,
  searchLiteratureDirect,
  similaritySearch,
  substructureSearch,
  scaffoldAnalysis,
  generateAnalogs,
  dockingStatus,
  quantumChemistry,
  molecularDynamics,
  RoadmapModule,
  SimilarityHit,
} from "../services/api";
import { AdmetCard } from "./AdmetCard";
import { LiteratureCard } from "./LiteratureCard";
import { MoleculeView } from "./MoleculeView";
import { Mol3DView } from "./Mol3DView";
import { Panel } from "./Panel";
import { MoleculeActions } from "./MoleculeActions";
import { useActiveMolecule } from "../context/ActiveMolecule";

export { Panel } from "./Panel";
export { ChatPanel } from "./ChatPanel";
export { LibraryPanel } from "./LibraryPanel";
export { BatchAdmetPanel } from "./BatchAdmetPanel";
export { MechanismPanel } from "./MechanismPanel";
export { ProteinPanel } from "./ProteinPanel";
export { PharmacophorePanel } from "./PharmacophorePanel";
export { RetroPanel } from "./RetroPanel";
export { TutorPanel } from "./TutorPanel";
export { MathPanel } from "./MathPanel";
export { PracticePanel } from "./PracticePanel";

const SAMPLE = "CC(=O)OC1=CC=CC=C1C(=O)O";

const SmilesInput: React.FC<{ value: string; onChange: (v: string) => void; onRun: () => void; loading: boolean; cta: string; placeholder?: string }> = ({
  value,
  onChange,
  onRun,
  loading,
  cta,
  placeholder = "Paste a SMILES string",
}) => (
  <div className="flex gap-2 mb-5">
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      onKeyDown={(e) => e.key === "Enter" && !loading && onRun()}
      placeholder={placeholder}
      className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm font-mono placeholder-ink-faint focus:outline-none focus:border-accent transition-colors"
    />
    <button
      onClick={onRun}
      disabled={loading || !value.trim()}
      className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30"
    >
      {loading ? "…" : cta}
    </button>
  </div>
);

// ── ADMET ────────────────────────────────────────────────────────────────
export const AdmetPanel: React.FC<{ library: Compound[] }> = ({ library }) => {
  const { smiles, setSmiles } = useActiveMolecule();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setErr(null);
    try {
      setResult(await predictAdmetDirect(smiles));
    } catch (e: any) {
      setErr(e.message);
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="ADMET & drug-likeness"
      purpose="Predicted absorption, distribution, and safety flags plus Lipinski Rule of Five."
      eyebrow="Analyze"
      engine="RDKit + ESOL + heuristic ADMET"
    >
      <SmilesInput value={smiles} onChange={setSmiles} onRun={run} loading={loading} cta="Predict" />
      {library.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-4">
          {library.map((c) => (
            <button key={c.name} onClick={() => setSmiles(c.smiles)} className="text-xs px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft transition-colors">
              {c.name}
            </button>
          ))}
        </div>
      )}
      {err && <div className="text-sm text-flag-risk">{err}</div>}
      {result?.valid && (
        <>
          <div className="flex flex-col md:flex-row gap-4 items-start">
            <MoleculeView smiles={result.smiles} size={200} />
            <div className="flex-1 w-full">
              <AdmetCard data={result} />
            </div>
          </div>
          <MoleculeActions smiles={result.smiles} targets={["scaffold", "similarity", "analogs", "mol3d", "pharmacophore", "retro"]} />
        </>
      )}
    </Panel>
  );
};

// ── Literature ─────────────────────────────────────────────────────────────
export const LiteraturePanel: React.FC = () => {
  const [q, setQ] = useState("KRAS G12C inhibitor selectivity");
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);
  const [refs, setRefs] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setErr(null);
    setAnswer(null);
    setRefs([]);
    try {
      const r = await searchLiteratureDirect(q);
      setAnswer(r.answer || null);
      setRefs(r.references || []);
      if (!r.references?.length) setErr(r.error || "No PubMed results found.");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="Literature search"
      purpose="Ask a question; get an answer grounded in real PubMed abstracts with citations."
      eyebrow="Search"
      engine="NCBI E-utilities · PubMed"
    >
      <SmilesInput value={q} onChange={setQ} onRun={run} loading={loading} cta="Search" placeholder="Ask a research question" />
      {err && <div className="text-sm text-flag-warn">{err}</div>}
      {answer && <div className="text-sm leading-relaxed whitespace-pre-wrap mb-2">{answer}</div>}
      {refs.length > 0 && <LiteratureCard references={refs} />}
    </Panel>
  );
};

// ── Similarity ─────────────────────────────────────────────────────────────
export const SimilarityPanel: React.FC<{ library: Compound[] }> = ({ library }) => {
  const { smiles, setSmiles } = useActiveMolecule();
  const [loading, setLoading] = useState(false);
  const [hits, setHits] = useState<SimilarityHit[]>([]);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setErr(null);
    try {
      const r = await similaritySearch(smiles, library);
      setHits(r.hits);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="Similarity search"
      purpose="Rank your compound library by Tanimoto similarity (Morgan fingerprints) to a query molecule."
      eyebrow="Search"
      engine="Morgan FP (r=2, 2048 bits) · Tanimoto"
    >
      <SmilesInput value={smiles} onChange={setSmiles} onRun={run} loading={loading} cta="Search" />
      {err && <div className="text-sm text-flag-risk">{err}</div>}
      {hits.length > 0 && (
        <div className="border border-line rounded bg-surface divide-y divide-line">
          {hits.map((h) => (
            <div key={h.name + h.smiles} className="px-3 py-2 flex items-center justify-between gap-3">
              <div className="w-[56px] flex-shrink-0"><MoleculeView smiles={h.smiles} size={56} /></div>
              <div className="min-w-0 flex-1">
                <div className="text-sm">{h.name}</div>
                <div className="text-[11px] text-ink-faint font-mono truncate">{h.smiles}</div>
                <div className="mt-1"><MoleculeActions smiles={h.smiles} compact targets={["admet", "scaffold", "mol3d", "analogs"]} /></div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <div className="w-24 h-1.5 bg-line rounded-full overflow-hidden">
                  <div className="h-full bg-accent" style={{ width: `${h.similarity * 100}%` }} />
                </div>
                <span className="text-sm font-mono w-12 text-right">{h.similarity.toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
};

// ── Substructure ───────────────────────────────────────────────────────────
export const SubstructurePanel: React.FC<{ library: Compound[] }> = ({ library }) => {
  const [pattern, setPattern] = useState("c1ccccc1");
  const [loading, setLoading] = useState(false);
  const [matches, setMatches] = useState<Compound[]>([]);
  const [count, setCount] = useState<number | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setErr(null);
    try {
      const r = await substructureSearch(pattern, library);
      setMatches(r.matches);
      setCount(r.match_count);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="Substructure search"
      purpose="Find every library compound containing a SMARTS or SMILES pattern."
      eyebrow="Search"
      engine="RDKit HasSubstructMatch"
    >
      <SmilesInput value={pattern} onChange={setPattern} onRun={run} loading={loading} cta="Match" placeholder="SMARTS or SMILES pattern" />
      {err && <div className="text-sm text-flag-risk">{err}</div>}
      {count !== null && (
        <div className="text-sm text-ink-muted mb-2">
          {count} of {library.length} compounds match.
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {matches.map((m) => (
          <div key={m.name + m.smiles}>
            <MoleculeView smiles={m.smiles} size={150} />
            <div className="text-xs mt-1">{m.name}</div>
          </div>
        ))}
      </div>
    </Panel>
  );
};

// ── Scaffold ───────────────────────────────────────────────────────────────
export const ScaffoldPanel: React.FC = () => {
  const { smiles, setSmiles } = useActiveMolecule();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setErr(null);
    try {
      setResult(await scaffoldAnalysis(smiles));
    } catch (e: any) {
      setErr(e.message);
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="Scaffold analysis"
      purpose="Extract the Bemis–Murcko scaffold — the ring-and-linker core that defines an analog series."
      eyebrow="Analyze"
      engine="RDKit MurckoScaffold"
    >
      <SmilesInput value={smiles} onChange={setSmiles} onRun={run} loading={loading} cta="Analyze" />
      {err && <div className="text-sm text-flag-risk">{err}</div>}
      {result?.valid && (
        <>
          <div className="flex flex-wrap gap-6">
            <div>
              <div className="text-xs text-ink-muted mb-1">Molecule</div>
              <MoleculeView smiles={result.smiles} size={180} />
            </div>
            <div>
              <div className="text-xs text-ink-muted mb-1">Murcko scaffold</div>
              <MoleculeView smiles={result.scaffold} size={180} />
              <MoleculeActions smiles={result.scaffold} compact targets={["similarity", "substructure", "literature", "analogs"]} />
            </div>
            <div>
              <div className="text-xs text-ink-muted mb-1">Generic framework · {result.ring_count} ring(s)</div>
              <MoleculeView smiles={result.generic_scaffold} size={180} />
            </div>
          </div>
        </>
      )}
    </Panel>
  );
};

// ── Analogs ────────────────────────────────────────────────────────────────
export const AnalogPanel: React.FC = () => {
  const { smiles, setSmiles } = useActiveMolecule();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = async () => {
    setLoading(true);
    setErr(null);
    try {
      setResult(await generateAnalogs(smiles));
    } catch (e: any) {
      setErr(e.message);
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Panel
      title="Analog generator"
      purpose="Enumerate close chemical relatives by single R-group swaps — a teaching-grade SAR starting point, not a validated enumeration engine."
      eyebrow="Design"
      engine="RDKit RunReactants · fixed swap palette"
    >
      <SmilesInput value={smiles} onChange={setSmiles} onRun={run} loading={loading} cta="Generate" />
      {err && <div className="text-sm text-flag-risk">{err}</div>}
      {result?.valid && (
        <>
          <div className="text-sm text-ink-muted mb-3">{result.count} analogs of the parent scaffold.</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {result.analogs.map((a: any, i: number) => (
              <div key={i}>
                <MoleculeView smiles={a.smiles} size={150} />
                <div className="text-[11px] text-ink-muted mt-1">{a.modification}</div>
                <MoleculeActions smiles={a.smiles} compact targets={["admet", "mol3d"]} />
              </div>
            ))}
          </div>
        </>
      )}
    </Panel>
  );
};

// ── Docking ────────────────────────────────────────────────────────────────
export const DockingPanel: React.FC = () => {
  const [status, setStatus] = useState<any>(null);
  useEffect(() => {
    dockingStatus().then(setStatus).catch(() => setStatus({ ready: false, detail: "Backend offline." }));
  }, []);

  return (
    <Panel
      title="Docking · AutoDock Vina"
      purpose="Score how a ligand fits a target protein pocket. Real docking — needs a prepared receptor."
      eyebrow="Simulate"
      engine="AutoDock Vina · Meeko"
    >
      <div className="border border-line rounded bg-surface p-4">
        <div className="flex items-center gap-2 mb-3">
          <span className={`inline-block w-2 h-2 rounded-full ${status?.ready ? "bg-flag-good" : "bg-flag-warn"}`} />
          <span className="text-sm">{status?.ready ? "Vina engine ready" : "Vina not detected"}</span>
        </div>
        <p className="text-sm text-ink-muted">{status?.detail}</p>
        <div className="mt-4 text-sm text-ink-muted">
          <div className="font-medium text-ink mb-1">To run a real docking:</div>
          <ol className="list-decimal list-inside space-y-1">
            <li>Download a target structure from the RCSB PDB.</li>
            <li>Prepare the receptor as PDBQT (Meeko or AutoDockTools).</li>
            <li>Identify the binding-pocket center coordinates.</li>
            <li>Submit ligand + receptor + search box to the docking endpoint.</li>
          </ol>
        </div>
      </div>
    </Panel>
  );
};

// ── 3D structure viewer ────────────────────────────────────────────────────
export const Mol3DPanel: React.FC<{ library: Compound[] }> = ({ library }) => {
  const { smiles, setSmiles } = useActiveMolecule();
  const [applied, setApplied] = useState(smiles);
  const [style, setStyle] = useState<"stick" | "sphere" | "line">("stick");

  // Re-embed automatically whenever the active molecule changes from elsewhere.
  useEffect(() => { setApplied(smiles); }, [smiles]);

  return (
    <Panel
      title="3D structure viewer"
      purpose="Real 3D conformer generated by RDKit ETKDGv3 embedding and MMFF minimization, rendered in-browser."
      eyebrow="Analyze"
      engine="RDKit ETKDGv3 · MMFF94 · 3Dmol.js"
      wide
    >
      <div className="flex gap-2 mb-4">
        <input
          value={smiles}
          onChange={(e) => setSmiles(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && setApplied(smiles)}
          className="flex-1 bg-surface border border-line rounded px-3 py-2 text-sm font-mono placeholder-ink-faint focus:outline-none focus:border-accent"
          placeholder="SMILES"
        />
        <select
          value={style}
          onChange={(e) => setStyle(e.target.value as "stick" | "sphere" | "line")}
          className="bg-surface border border-line rounded px-3 py-2 text-sm focus:outline-none focus:border-accent"
        >
          <option value="stick">Stick + sphere</option>
          <option value="sphere">Sphere</option>
          <option value="line">Line</option>
        </select>
        <button
          onClick={() => setApplied(smiles)}
          disabled={!smiles.trim()}
          className="px-4 py-2 bg-ink text-paper text-sm rounded hover:bg-accent-strong transition-colors disabled:opacity-30"
        >
          Embed
        </button>
      </div>
      {library.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-4">
          {library.map((c) => (
            <button
              key={c.name + c.smiles}
              onClick={() => {
                setSmiles(c.smiles);
                setApplied(c.smiles);
              }}
              className="text-xs px-2 py-1 border border-line rounded hover:border-accent hover:bg-accent-soft transition-colors"
            >
              {c.name}
            </button>
          ))}
        </div>
      )}
      <Mol3DView smiles={applied} style={style} height={420} />
    </Panel>
  );
};

// ── Roadmap (QM / MD) ───────────────────────────────────────────────────────
export const RoadmapPanel: React.FC<{ kind: "quantum" | "dynamics" }> = ({ kind }) => {
  const [data, setData] = useState<RoadmapModule | null>(null);
  useEffect(() => {
    const fn = kind === "quantum" ? quantumChemistry : molecularDynamics;
    fn(SAMPLE).then(setData).catch(() => setData(null));
  }, [kind]);

  const title = kind === "quantum" ? "Quantum chemistry" : "Molecular dynamics";
  const purpose =
    kind === "quantum"
      ? "Electronic structure — HOMO/LUMO, optimized geometry, electrostatics."
      : "Time-evolution of a molecule or complex — stability, RMSD, binding-pose persistence.";

  return (
    <Panel
      title={title}
      purpose={purpose}
      eyebrow="Simulate"
      engine={kind === "quantum" ? "Psi4 (planned)" : "OpenMM + GPU (planned)"}
    >
      <div className="inline-flex items-center gap-2 px-2.5 py-1 border border-flag-warn rounded text-xs text-flag-warn mb-4">
        <span className="inline-block w-1.5 h-1.5 rounded-full bg-flag-warn" />
        Planned module — not live in this prototype
      </div>
      {data && (
        <div className="space-y-4">
          <div>
            <div className="text-xs text-ink-muted mb-1.5">What it would compute</div>
            <ul className="space-y-1">
              {data.would_compute.map((w) => (
                <li key={w} className="text-sm flex gap-2">
                  <span className="text-ink-faint">·</span>
                  {w}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="text-xs text-ink-muted mb-1">Engine when built</div>
            <div className="text-sm font-mono">{data.engine_when_built}</div>
          </div>
          <div>
            <div className="text-xs text-ink-muted mb-1">Why it's not a click-to-run feature yet</div>
            <p className="text-sm text-ink-muted leading-relaxed">{data.why_not_now}</p>
          </div>
        </div>
      )}
    </Panel>
  );
};
