import { createContext, useContext, useState, ReactNode } from "react";

type NavigateFn = (moduleId: string) => void;

interface Ctx {
  smiles: string;
  setSmiles: (s: string) => void;
  navigate: NavigateFn;
  registerNavigator: (fn: NavigateFn) => void;
}

const ActiveMoleculeContext = createContext<Ctx>({
  smiles: "CC(=O)Oc1ccccc1C(=O)O",
  setSmiles: () => {},
  navigate: () => {},
  registerNavigator: () => {},
});

export const useActiveMolecule = () => useContext(ActiveMoleculeContext);

export function ActiveMoleculeProvider({ children }: { children: ReactNode }) {
  const [smiles, setSmiles] = useState("CC(=O)Oc1ccccc1C(=O)O");
  const [navigate, setNavigate] = useState<NavigateFn>(() => () => {});
  const registerNavigator = (fn: NavigateFn) => setNavigate(() => fn);
  return (
    <ActiveMoleculeContext.Provider value={{ smiles, setSmiles, navigate, registerNavigator }}>
      {children}
    </ActiveMoleculeContext.Provider>
  );
}
