import { createContext, useContext, useState, ReactNode } from "react";

export type Subject = "math" | "chemistry" | "physics" | "biology" | "cs" | "english" | "history" | "general";
export type Grade   = "g4-6" | "g7-9" | "g10-12" | "uni-y1" | "uni-y2";

export const SUBJECTS: { id: Subject; label: string }[] = [
  { id: "math",      label: "Math" },
  { id: "chemistry", label: "Chemistry" },
  { id: "physics",   label: "Physics" },
  { id: "biology",   label: "Biology" },
  { id: "cs",        label: "CS" },
  { id: "english",   label: "English" },
  { id: "history",   label: "History" },
  { id: "general",   label: "General" },
];

export const GRADES: { id: Grade; label: string }[] = [
  { id: "g4-6",   label: "Grade 4–6" },
  { id: "g7-9",   label: "Grade 7–9" },
  { id: "g10-12", label: "Grade 10–12" },
  { id: "uni-y1", label: "University · Year 1" },
  { id: "uni-y2", label: "University · Year 2" },
];

interface Ctx {
  subject: Subject;
  grade: Grade;
  setSubject: (s: Subject) => void;
  setGrade: (g: Grade) => void;
}

const StudySessionContext = createContext<Ctx>({
  subject: "general",
  grade: "uni-y1",
  setSubject: () => {},
  setGrade: () => {},
});

export const useStudySession = () => useContext(StudySessionContext);

export function StudySessionProvider({ children }: { children: ReactNode }) {
  const [subject, setSubject] = useState<Subject>("general");
  const [grade, setGrade] = useState<Grade>("uni-y1");
  return (
    <StudySessionContext.Provider value={{ subject, grade, setSubject, setGrade }}>
      {children}
    </StudySessionContext.Provider>
  );
}
