const API_BASE_URL = "http://localhost:8000";

export interface AdmetProperty {
  name: string;
  value: number;
  unit: string;
  description: string;
  flag: "green" | "amber" | "red";
}

export interface LipinskiData {
  mw: number;
  hbd: number;
  hba: number;
  logp: number;
  tpsa: number;
  violations: number;
  passes: boolean;
}

export interface AdmetResponse {
  valid: boolean;
  smiles?: string;
  properties?: Record<string, AdmetProperty>;
  lipinski?: LipinskiData;
  source?: string;
  error?: string;
}

export interface ReferenceItem {
  title: string;
  authors: string;
  journal: string;
  year: string;
  pmid: string;
  url: string;
  abstract?: string;
}

export interface LiteratureResponse {
  answer: string;
  references: ReferenceItem[];
  error?: string;
}

export type ChatToolKind =
  | "admet"
  | "pubmed"
  | "similarity"
  | "substructure"
  | "scaffold"
  | "analogs"
  | "mol3d"
  | "library"
  | "docking";

export interface ChatToolData {
  tool: ChatToolKind;
  // Loose payload — the frontend picks a renderer per `tool`.
  data: unknown;
}

export interface ChatResponse {
  response: string;
  tool_used: ChatToolKind | null;
  admet_data?: AdmetResponse | null;
  literature_data?: ReferenceItem[] | null;
  tool_data?: ChatToolData | null;
}

export async function checkHealth(): Promise<{ status: string; anthropic_configured: boolean }> {
  try {
    const res = await fetch(`${API_BASE_URL}/health`);
    if (!res.ok) throw new Error("Health check failed");
    return await res.json();
  } catch {
    return { status: "offline", anthropic_configured: false };
  }
}

export async function sendChatMessage(
  message: string,
  history: { role: string; content: string }[],
  apiKey?: string,
): Promise<ChatResponse> {
  const res = await fetch(`${API_BASE_URL}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history, api_key: apiKey || undefined }),
  });
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || "Failed to send chat message");
  }
  return await res.json();
}

export async function predictAdmetDirect(smiles: string): Promise<AdmetResponse> {
  const res = await fetch(`${API_BASE_URL}/admet`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  const data = await res.json();
  if (!res.ok || !data.valid) {
    throw new Error(data.error || "Invalid SMILES string");
  }
  return data;
}

export async function searchLiteratureDirect(query: string): Promise<LiteratureResponse> {
  const res = await fetch(`${API_BASE_URL}/literature?q=${encodeURIComponent(query)}`);
  const data = await res.json();
  if (!res.ok && res.status !== 404) {
    throw new Error(data.error || "Failed to fetch PubMed literature");
  }
  return data;
}

// ── Cheminformatics toolkit ──────────────────────────────────────────────

export interface Compound {
  name: string;
  smiles: string;
}

export interface LibraryCompound extends Compound {
  id: number;
  canonical_smiles: string;
  tag: string;
  created_at: string;
}

export async function depictMolecule(
  smiles: string,
): Promise<{ valid: boolean; svg?: string; smiles?: string; error?: string }> {
  const res = await fetch(`${API_BASE_URL}/depict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  return await res.json();
}

export interface SimilarityHit {
  name: string;
  smiles: string;
  similarity: number;
}

export async function similaritySearch(smiles: string, library: Compound[], topK = 10) {
  const res = await fetch(`${API_BASE_URL}/similarity`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles, library, top_k: topK }),
  });
  const data = await res.json();
  if (!data.valid) throw new Error(data.error || "Similarity search failed");
  return data as { valid: boolean; query: string; hits: SimilarityHit[]; searched: number };
}

export async function substructureSearch(pattern: string, library: Compound[]) {
  const res = await fetch(`${API_BASE_URL}/substructure`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ pattern, library }),
  });
  const data = await res.json();
  if (!data.valid) throw new Error(data.error || "Substructure search failed");
  return data as {
    valid: boolean;
    pattern: string;
    matches: Compound[];
    match_count: number;
    searched: number;
  };
}

export async function scaffoldAnalysis(smiles: string) {
  const res = await fetch(`${API_BASE_URL}/scaffold`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  const data = await res.json();
  if (!data.valid) throw new Error(data.error || "Scaffold analysis failed");
  return data as {
    valid: boolean;
    smiles: string;
    scaffold: string;
    generic_scaffold: string;
    ring_count: number;
  };
}

export async function generateAnalogs(smiles: string) {
  const res = await fetch(`${API_BASE_URL}/analogs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  const data = await res.json();
  if (!data.valid) throw new Error(data.error || "Analog generation failed");
  return data as {
    valid: boolean;
    parent: string;
    analogs: { smiles: string; modification: string }[];
    count: number;
  };
}

// ── Advanced modules ─────────────────────────────────────────────────────

export interface RoadmapModule {
  module: string;
  status: string;
  live: boolean;
  would_compute: string[];
  engine_when_built: string;
  why_not_now: string;
  smiles: string;
}

export async function dockingStatus() {
  const res = await fetch(`${API_BASE_URL}/docking/status`);
  return await res.json();
}

export async function quantumChemistry(smiles: string): Promise<RoadmapModule> {
  const res = await fetch(`${API_BASE_URL}/quantum`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  return await res.json();
}

export async function molecularDynamics(smiles: string): Promise<RoadmapModule> {
  const res = await fetch(`${API_BASE_URL}/dynamics`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  return await res.json();
}

// ── Compound library (SQLite) ────────────────────────────────────────────

export async function listLibrary(): Promise<LibraryCompound[]> {
  const res = await fetch(`${API_BASE_URL}/library`);
  const data = await res.json();
  return data.compounds || [];
}

export async function addLibraryCompound(name: string, smiles: string, tag = ""): Promise<LibraryCompound> {
  const res = await fetch(`${API_BASE_URL}/library`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, smiles, tag }),
  });
  const data = await res.json();
  if (!res.ok || !data.valid) throw new Error(data.error || "Failed to add compound");
  return data.compound;
}

export async function deleteLibraryCompound(id: number): Promise<void> {
  const res = await fetch(`${API_BASE_URL}/library/${id}`, { method: "DELETE" });
  const data = await res.json();
  if (!res.ok || !data.valid) throw new Error(data.error || "Failed to delete compound");
}

// ── 3D structure ─────────────────────────────────────────────────────────

export interface Mol3DResponse {
  valid: boolean;
  smiles?: string;
  molblock?: string;
  forcefield?: string;
  num_atoms?: number;
  num_bonds?: number;
  error?: string;
}

export async function generate3D(smiles: string): Promise<Mol3DResponse> {
  const res = await fetch(`${API_BASE_URL}/mol3d`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  return await res.json();
}

// ── Batch ADMET ──────────────────────────────────────────────────────────

export interface BatchAdmetRow {
  name: string;
  smiles: string;
  valid: boolean;
  error?: string;
  mw?: number;
  logp?: number;
  tpsa?: number;
  hbd?: number;
  hba?: number;
  lipinski_pass?: boolean;
  lipinski_violations?: number;
  logS?: number;
  hia?: number;
  bbb?: number;
  herg?: number;
  logS_flag?: string;
  logP_flag?: string;
  hia_flag?: string;
  bbb_flag?: string;
  herg_flag?: string;
}

export async function batchAdmet(compounds: Compound[]): Promise<{ rows: BatchAdmetRow[]; count: number }> {
  const res = await fetch(`${API_BASE_URL}/admet/batch`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ compounds }),
  });
  return await res.json();
}

// ── Study: Mechanism Explorer ────────────────────────────────────────────

export interface MechanismSideMol {
  smiles_input: string;
  smiles?: string;
  svg?: string | null;
  valid: boolean;
  error?: string;
}

export interface MechanismStep {
  index: number;
  title: string;
  reactants: MechanismSideMol[];
  products: MechanismSideMol[];
  arrow_pushing: string;
  notes?: string;
}

export interface MechanismResponse {
  valid: boolean;
  needs_key?: boolean;
  error?: string;
  question?: string;
  reaction_name?: string;
  overview?: string;
  steps?: MechanismStep[];
  principles?: string[];
  pitfalls?: string[];
  smiles_validation?: { total: number; valid: number };
  caveat?: string;
}

export async function studyMechanism(question: string, apiKey?: string): Promise<MechanismResponse> {
  const res = await fetch(`${API_BASE_URL}/study/mechanism`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, api_key: apiKey || undefined }),
  });
  return await res.json();
}

// ── Protein loader ───────────────────────────────────────────────────────

export interface ProteinResponse {
  valid: boolean;
  pdb_id?: string;
  title?: string;
  chains?: string[];
  ligands?: string[];
  resolution_A?: number | null;
  num_atoms?: number;
  pdb?: string;
  error?: string;
}

export async function fetchProtein(pdbId: string): Promise<ProteinResponse> {
  const res = await fetch(`${API_BASE_URL}/protein/${encodeURIComponent(pdbId)}`);
  return await res.json();
}

// ── Pharmacophore ────────────────────────────────────────────────────────

export interface PharmacophoreFeature {
  family: string;
  type: string;
  atom_indices: number[];
}

export interface PharmacophoreResponse {
  valid: boolean;
  smiles?: string;
  features?: PharmacophoreFeature[];
  counts?: Record<string, number>;
  error?: string;
}

export async function extractPharmacophore(smiles: string): Promise<PharmacophoreResponse> {
  const res = await fetch(`${API_BASE_URL}/pharmacophore`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  return await res.json();
}

export interface OverlayResponse {
  valid: boolean;
  query_smiles?: string;
  reference_smiles?: string;
  rmsd_A?: number;
  o3a_score?: number;
  query_molblock?: string;
  reference_molblock?: string;
  error?: string;
}

export async function shapeOverlay(querySmiles: string, referenceSmiles: string): Promise<OverlayResponse> {
  const res = await fetch(`${API_BASE_URL}/pharmacophore/overlay`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query_smiles: querySmiles, reference_smiles: referenceSmiles }),
  });
  return await res.json();
}

// ── Retrosynthesis ───────────────────────────────────────────────────────

export interface RetroDisconnection {
  name: string;
  description: string;
  fragments: string[];
}

export interface RetroResponse {
  valid: boolean;
  target?: string;
  disconnections?: RetroDisconnection[];
  count?: number;
  note?: string;
  error?: string;
}

export async function retrosynthesize(smiles: string): Promise<RetroResponse> {
  const res = await fetch(`${API_BASE_URL}/retro`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ smiles }),
  });
  return await res.json();
}

// ── Learn: tutor, math, practice ─────────────────────────────────────────

export interface TutorResponse {
  valid: boolean;
  needs_key?: boolean;
  error?: string;
  response?: string;
  subject?: string;
  grade?: string;
}

export async function tutorAsk(
  question: string,
  subject: string,
  grade: string,
  history: { role: string; content: string }[],
  apiKey?: string,
): Promise<TutorResponse> {
  const res = await fetch(`${API_BASE_URL}/tutor`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, subject, grade, history, api_key: apiKey || undefined }),
  });
  return await res.json();
}

export type MathOperation = "solve" | "diff" | "integrate" | "factor" | "expand" | "simplify" | "limit" | "series";

export interface MathResponse {
  valid: boolean;
  operation?: string;
  input?: string;
  input_latex?: string;
  output?: string;
  output_latex?: string;
  steps?: string[];
  error?: string;
}

export interface MathRequestArgs {
  expression: string;
  operation: MathOperation;
  variable?: string;
  lower?: string;
  upper?: string;
  order?: number;
}

export async function mathSolve(args: MathRequestArgs): Promise<MathResponse> {
  const res = await fetch(`${API_BASE_URL}/math/solve`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  return await res.json();
}

export interface PracticeProblem {
  index: number;
  question: string;
  answer: string;
  solution: string;
  hint?: string;
}

export interface PracticeResponse {
  valid: boolean;
  needs_key?: boolean;
  error?: string;
  subject?: string;
  grade?: string;
  topic?: string;
  problems?: PracticeProblem[];
}

export async function practiceGenerate(
  subject: string,
  grade: string,
  topic: string,
  count: number,
  apiKey?: string,
): Promise<PracticeResponse> {
  const res = await fetch(`${API_BASE_URL}/practice`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ subject, grade, topic, count, api_key: apiKey || undefined }),
  });
  return await res.json();
}

export async function practiceCheck(student: string, canonical: string): Promise<{ correct: boolean; note: string }> {
  const res = await fetch(`${API_BASE_URL}/practice/check`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ student, canonical }),
  });
  return await res.json();
}
