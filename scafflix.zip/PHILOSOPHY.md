# What makes a great STEM AI tutor

Stepping back from Scafflix for this one — this is a genuinely different question, and worth thinking about carefully, because "what people say they want" and "what actually helps them learn" diverge a lot with tutoring.

## The uncomfortable core

The single most valuable quality is one most people don't enjoy in the moment — it makes you do the work rather than doing it for you. A tutor that hands you the answer feels great and teaches almost nothing. The research on this is consistent: retrieval, struggle, and self-explanation are where learning happens. So the best STEM AI tutor withholds strategically — asks what you think first, gives a hint before a solution, makes you attempt the next step. Everything below sits underneath that.

## Correctness, and knowing its own limits

In STEM this is non-negotiable in a way it isn't for, say, an essay-brainstorming tool. A confident wrong derivation is actively harmful — you'll memorize the error. So you want a tutor that's accurate, shows its work so you can check it rather than trust it, and flags uncertainty instead of bluffing. *"I'm not sure about this constant, let's verify it"* is a feature, not a weakness.

## Meets you at your actual level

Good tutoring is diagnostic — it figures out where your understanding breaks and targets that, instead of re-explaining what you already know or assuming background you lack. A fixed explanation is a lecture; a tutor adapts to the specific misconception. This means asking questions, not just answering them.

## Diagnoses the misconception, doesn't just mark it wrong

When you get something wrong in STEM, there's almost always a specific broken mental model behind it — a sign error, a units confusion, thinking correlation implies causation. A great tutor finds *why* you got it wrong and fixes the model, so the whole class of error goes away, rather than just correcting this one answer.

## Multiple representations

Hard STEM concepts click differently for different people and different topics — sometimes it's the equation, sometimes a diagram, sometimes a physical analogy, sometimes worked numbers. A tutor that can show the same idea several ways, and switch when one isn't landing, is far more useful than one with a single explanation style.

## Builds intuition, not just procedure

The difference between *"I can plug into the formula"* and *"I understand what the formula means."* The best tutors connect to why it's true, where it comes from, when it breaks — because that's what transfers to problems you haven't seen. Procedure alone collapses the moment a question is phrased unfamiliarly.

## Patience without judgment, and real encouragement

STEM is where people quietly decide they're "not a math person" and give up. A tutor you're not embarrassed to ask a basic question, that treats confusion as normal and doesn't make you feel slow, keeps you in the game long enough to actually improve. Persistence is most of the battle, and morale drives persistence.

## Rigor about notation and precision

Units, significant figures, exact definitions, careful notation — the discipline that separates STEM from hand-waving. A good tutor holds you to it, because sloppiness there is where real errors hide.

## Honesty over flattery

Related to the first point but distinct: you want a tutor that tells you when your reasoning is actually wrong, not one that praises everything to keep you happy. False reassurance in STEM means you walk into the exam confident and unprepared. Kind, but honest.

## Two things worth naming that people want but should be a little wary of

**Speed.** Instant answers can short-circuit the productive struggle that's doing the actual teaching.

**Infinite availability.** Real, and a genuine advantage over a human tutor you see once a week — but it can also become a crutch, where you outsource thinking you should be building.

The tool being good and the tool being good *for you* aren't automatically the same thing, and the best design actively protects the learning even when the user would rather just have the answer.

## In one line

A great STEM AI tutor is **accurate, adapts to you, explains the why, and makes you do the thinking** — warmly, but without letting you off the hook.

---

*Is this for a product idea, or for choosing/using one yourself? The answer shifts emphasis a fair bit depending on which.*
